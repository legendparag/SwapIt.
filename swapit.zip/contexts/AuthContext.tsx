import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import type { User, UserProfile } from '../types';
import { getMockUserProfile, MOCK_USERS, saveMockUser, addCoinTransaction } from '../services/api';

interface AuthContextType {
  isAuthenticated: boolean;
  currentUser: UserProfile | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  signup: (userData: Omit<User, 'avatarUrl' | 'location' | 'memberSince' | 'totalCoinsEarned' | 'itemsListed' | 'swapsCompleted' | 'badge'>) => Promise<void>;
  addCoins: (amount: number) => Promise<void>;
  refreshCurrentUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const fetchAndSetUser = async (username: string) => {
    try {
        const userProfile = await getMockUserProfile(username);
        setCurrentUser(userProfile);
    } catch (error) {
        console.error("Failed to fetch user profile", error);
        localStorage.removeItem('currentUser');
        setCurrentUser(null);
    }
  };

  useEffect(() => {
    const checkLoggedInUser = async () => {
      setIsLoading(true);
      const storedUserString = localStorage.getItem('currentUser');
      if (storedUserString) {
        const storedUser = JSON.parse(storedUserString) as User;
        await fetchAndSetUser(storedUser.username);
      }
      setIsLoading(false);
    };
    checkLoggedInUser();
  }, []);

  const refreshCurrentUser = useCallback(async () => {
    const storedUserString = localStorage.getItem('currentUser');
    if (storedUserString) {
        const storedUser = JSON.parse(storedUserString) as User;
        await fetchAndSetUser(storedUser.username);
    }
  }, []);

  const login = useCallback(async (username: string, password: string) => {
    const user = MOCK_USERS.find(u => u.username === username && u.password === password);
    if (user) {
      localStorage.setItem('currentUser', JSON.stringify(user));
      await fetchAndSetUser(user.username);
      navigate('/home');
    } else {
      throw new Error('Invalid username or password.');
    }
  }, [navigate]);

  const logout = useCallback(() => {
    localStorage.removeItem('currentUser');
    setCurrentUser(null);
    navigate('/login');
  }, [navigate]);

  const signup = useCallback(async (userData: Omit<User, 'avatarUrl' | 'location' | 'memberSince' | 'totalCoinsEarned' | 'itemsListed' | 'swapsCompleted' | 'badge'>) => {
    const existingUser = MOCK_USERS.find(u => u.username === userData.username);
    if (existingUser) {
      throw new Error('Username already exists.');
    }
    
    const newUser: User = {
        ...userData,
        name: userData.name,
        username: userData.username,
        dob: userData.dob,
        password: userData.password,
        avatarUrl: `https://i.pravatar.cc/150?u=${userData.username}`,
        location: 'New City, NC',
        memberSince: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long'}),
        totalCoinsEarned: 100,
        itemsListed: 0,
        swapsCompleted: 0,
        badge: 'Bronze',
    };

    saveMockUser(newUser);

    const date = new Date();
    const expiryDate = new Date();
    expiryDate.setDate(date.getDate() + 30); // 30 day expiry for bonus coins

    await addCoinTransaction({
        type: 'Credit',
        description: 'Welcome Bonus',
        amount: 100,
        date: date.toLocaleDateString('en-CA'),
        expiryDate: expiryDate.toLocaleDateString('en-CA'),
        source: 'bonus'
    }, newUser.username);

    localStorage.setItem('currentUser', JSON.stringify(newUser));
    await fetchAndSetUser(newUser.username);
    navigate('/home');
  }, [navigate]);

  const addCoins = useCallback(async (amount: number) => {
    if (!currentUser) return;
    const date = new Date().toLocaleDateString('en-CA');
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 90); // 90 days expiry for purchased coins

    await addCoinTransaction({
        type: 'Credit',
        description: 'Purchased Coins',
        amount: amount,
        date: date,
        expiryDate: expiryDate.toLocaleDateString('en-CA'),
        source: 'purchased'
    }, currentUser.username);
  }, [currentUser]);

  const value = {
    isAuthenticated: !!currentUser,
    currentUser,
    isLoading,
    login,
    logout,
    signup,
    addCoins,
    refreshCurrentUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};