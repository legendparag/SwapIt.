import type { Item, Swap, CoinTransaction, UserProfile, RepairGuidance, User, ChatConversation, ChatMessage } from '../types';

// --- MOCK USER DATA ---

const defaultUsers: User[] = [
    {
      name: 'Alex Swapper',
      username: 'alex_swapper',
      password: 'password123',
      avatarUrl: 'https://i.pravatar.cc/150?u=alex_swapper',
      location: 'San Francisco, CA',
      memberSince: 'January 2022',
      totalCoinsEarned: 5850,
      itemsListed: 12,
      swapsCompleted: 28,
      dob: '1990-05-15',
      badge: 'Gold',
    },
    { name: 'Photo Fan', username: 'photo_fan', password: 'password123', avatarUrl: 'https://i.pravatar.cc/150?u=photo_fan', location: 'Austin, TX', memberSince: 'March 2023', totalCoinsEarned: 1200, itemsListed: 1, swapsCompleted: 5, dob: '1992-08-20', badge: 'Silver' },
    { name: 'Crafty Carla', username: 'crafty_carla', password: 'password123', avatarUrl: 'https://i.pravatar.cc/150?u=crafty_carla', location: 'Seattle, WA', memberSince: 'June 2022', totalCoinsEarned: 600, itemsListed: 1, swapsCompleted: 3, dob: '1988-11-05', badge: 'Bronze' },
    { name: 'Retro Gamer', username: 'retro_gamer', password: 'password123', avatarUrl: 'https://i.pravatar.cc/150?u=retro_gamer', location: 'Portland, OR', memberSince: 'February 2022', totalCoinsEarned: 2500, itemsListed: 1, swapsCompleted: 10, dob: '1995-02-10', badge: 'Silver' },
    { name: 'Fashionista Fay', username: 'fashionista_fay', password: 'password123', avatarUrl: 'https://i.pravatar.cc/150?u=fashionista_fay', location: 'New York, NY', memberSince: 'May 2023', totalCoinsEarned: 3500, itemsListed: 1, swapsCompleted: 8, dob: '1998-07-22', badge: 'Silver' },
];

const initializeUsers = (): User[] => {
    const storedUsers = localStorage.getItem('MOCK_USERS_DB');
    if (storedUsers) {
        try {
            const parsedUsers = JSON.parse(storedUsers);
            if (Array.isArray(parsedUsers) && parsedUsers.length > 0) {
                return parsedUsers;
            }
        } catch (e) {
            console.error("Failed to parse users from localStorage", e);
        }
    }
    localStorage.setItem('MOCK_USERS_DB', JSON.stringify(defaultUsers));
    return defaultUsers;
};

export let MOCK_USERS: User[] = initializeUsers();

const persistUsers = () => {
    localStorage.setItem('MOCK_USERS_DB', JSON.stringify(MOCK_USERS));
}

export const saveMockUser = (user: User) => {
    if (!MOCK_USERS.some(u => u.username === user.username)) {
        MOCK_USERS.push(user);
        persistUsers();
    }
};


// MOCK ITEMS
const mockItems: Item[] = [
  { id: 'm1', name: 'Vintage Polaroid Camera', description: 'Classic 600-series Polaroid camera. Tested and working. Includes one pack of film.', imageUrl: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?&auto=format&fit=crop&w=300&q=60', condition: 'Used - Good', value: 1200, category: 'Electronics', listedDate: '2024-07-20T10:00:00Z', owner: { username: 'photo_fan', avatarUrl: 'https://i.pravatar.cc/150?u=photo_fan' }, distance: 2.5 },
  { id: 'm2', name: 'Handmade Ceramic Mug Set', description: 'Set of four beautiful, handmade ceramic mugs. Microwave and dishwasher safe.', imageUrl: 'https://images.unsplash.com/photo-1587316821143-a2095964091a?&auto=format&fit=crop&w=300&q=60', condition: 'New', value: 600, category: 'Other', listedDate: '2024-07-21T11:30:00Z', owner: { username: 'crafty_carla', avatarUrl: 'https://i.pravatar.cc/150?u=crafty_carla' }, distance: 8.1 },
  { id: 'm3', name: 'Retro Gaming Console', description: 'A classic console from the 90s, comes with two controllers and three popular games.', imageUrl: 'https://images.unsplash.com/photo-1593152194541-3642d16954a2?&auto=format&fit=crop&w=300&q=60', condition: 'Used - Fair', value: 2500, category: 'Electronics', listedDate: '2024-07-19T14:00:00Z', owner: { username: 'retro_gamer', avatarUrl: 'https://i.pravatar.cc/150?u=retro_gamer' }, distance: 5.3 },
  { id: 'm4', name: 'Designer Denim Jacket', description: 'Lightly worn designer denim jacket. Excellent condition, no stains or tears. Size Medium.', imageUrl: 'https://images.unsplash.com/photo-1591047139829-d916e6ca8446?&auto=format&fit=crop&w=300&q=60', condition: 'Used - Like New', value: 3500, category: 'Apparel', listedDate: '2024-07-22T09:00:00Z', owner: { username: 'fashionista_fay', avatarUrl: 'https://i.pravatar.cc/150?u=fashionista_fay' }, distance: 12.0 },
  { id: 'm5', name: 'Mid-Century Modern Chair', description: 'Authentic mid-century armchair. Solid wood frame with original upholstery. Some minor wear.', imageUrl: 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?&auto=format&fit=crop&w=300&q=60', condition: 'Used - Good', value: 8000, category: 'Furniture', listedDate: '2024-07-18T18:00:00Z', owner: { username: 'design_dave', avatarUrl: 'https://i.pravatar.cc/150?u=design_dave' }, distance: 3.8 },
  { id: 'm6', name: 'Rare Vinyl Record', description: 'First pressing of a classic rock album. Sleeve has some shelf wear but the record is in great shape.', imageUrl: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?&auto=format&fit=crop&w=300&q=60', condition: 'Used - Good', value: 1800, category: 'Collectibles', listedDate: '2024-07-21T15:20:00Z', owner: { username: 'music_man', avatarUrl: 'https://i.pravatar.cc/150?u=music_man' }, distance: 15.2 },
  { id: 'm7', name: 'Professional DSLR Camera', description: 'High-end DSLR camera body. Shutter count is around 15k. Perfect for professionals or enthusiasts.', imageUrl: 'https://images.unsplash.com/photo-1512756290469-ec264b7fbf87?&auto=format&fit=crop&w=300&q=60', condition: 'Used - Like New', value: 15000, category: 'Electronics', listedDate: '2024-07-22T10:00:00Z', owner: { username: 'pro_snapper', avatarUrl: 'https://i.pravatar.cc/150?u=pro_snapper' }, distance: 1.1 },
  { id: 'm8', name: 'Antique Pocket Watch', description: 'A beautiful silver pocket watch from the early 1900s. Still keeps time accurately.', imageUrl: 'https://images.unsplash.com/photo-1615152528141-97b4129a39f6?&auto=format&fit=crop&w=300&q=60', condition: 'Used - Good', value: 5500, category: 'Collectibles', listedDate: '2024-07-17T12:00:00Z', owner: { username: 'time_traveler', avatarUrl: 'https://i.pravatar.cc/150?u=time_traveler' }, distance: 22.4 },
];

const mockUserItems: Item[] = [
    { id: 'u1', name: 'Vintage Leather Jacket', description: 'Well-loved leather jacket with a great patina. All zippers work. Size Large.', imageUrl: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?&auto=format&fit=crop&w=300&q=60', condition: 'Used - Good', value: 4000, category: 'Apparel', listedDate: '2024-07-15T09:00:00Z', owner: { username: 'alex_swapper', avatarUrl: 'https://i.pravatar.cc/150?u=alex_swapper' }, distance: 0 },
    { id: 'u2', name: 'Acoustic Guitar', description: 'Beginner-level acoustic guitar. Holds tune well. A few minor scratches on the back.', imageUrl: 'https://images.unsplash.com/photo-1510915361894-db8b60106945?&auto=format&fit=crop&w=300&q=60', condition: 'Used - Good', value: 2200, category: 'Other', listedDate: '2024-07-10T14:30:00Z', owner: { username: 'alex_swapper', avatarUrl: 'https://i.pravatar.cc/150?u=alex_swapper' }, distance: 0 },
];

// Single source of truth for all items
let allItems: Item[] = [...mockItems, ...mockUserItems];

// MOCK SWAPS
let mockSwaps: Swap[] = [
  { id: 's1', userItem: mockUserItems[0], otherUserItem: mockItems.find(i => i.id === 'm3')!, proposerUsername: 'alex_swapper', status: 'Completed', date: '2024-07-18', feedbackGiven: true, coinDifference: 1500 },
  { id: 's2', userItem: mockUserItems[1], otherUserItem: mockItems.find(i => i.id === 'm2')!, proposerUsername: 'alex_swapper', status: 'Pending', date: '2024-07-21', coinDifference: 1600 },
  { id: 's3', userItem: { ...mockUserItems[0], id: 'u3' }, otherUserItem: mockItems.find(i => i.id === 'm4')!, proposerUsername: 'fashionista_fay', status: 'Accepted', date: '2024-07-22', coinDifference: -500 },
  { id: 's4', userItem: { ...mockUserItems[1], id: 'u4' }, otherUserItem: mockItems.find(i => i.id === 'm1')!, proposerUsername: 'alex_swapper', status: 'Rejected', date: '2024-07-19', coinDifference: 1000 },
];

// MOCK TRANSACTIONS
let mockTransactions: CoinTransaction[] = [
  { id: 't1', username: 'alex_swapper', type: 'Credit', description: "Swap for 'Retro Gaming Console'", amount: 1500, date: '2024-07-18', expiryDate: '2024-08-17', source: 'earned' },
  { id: 't2', username: 'alex_swapper', type: 'Credit', description: 'Welcome Bonus', amount: 500, date: '2024-07-01', expiryDate: '2024-07-31', source: 'bonus' },
  { id: 't3', username: 'alex_swapper', type: 'Credit', description: 'Purchased Coins', amount: 2000, date: '2024-07-10', expiryDate: '2024-10-08', source: 'purchased' },
  { id: 't4', username: 'alex_swapper', type: 'Debit', description: "Swap with 'fashionista_fay'", amount: -500, date: '2024-07-22', expiryDate: '', source: 'swap' },
  { id: 't5', username: 'alex_swapper', type: 'Credit', description: "Referral Bonus", amount: 250, date: '2024-06-25', expiryDate: '2024-07-25', source: 'bonus' },
];

const mockConversations: ChatConversation[] = [
    {
        id: 'convo1',
        item: { id: 'm1', name: 'Vintage Polaroid Camera', imageUrl: mockItems[0].imageUrl },
        otherUser: { username: 'photo_fan', avatarUrl: mockItems[0].owner.avatarUrl },
        lastMessage: { text: 'Is it still available? I have a guitar to trade.', timestamp: '2024-07-22T14:30:00Z', senderUsername: 'photo_fan' },
        unreadCount: 1,
    },
    {
        id: 'convo2',
        item: { id: 'm3', name: 'Retro Gaming Console', imageUrl: mockItems[2].imageUrl },
        otherUser: { username: 'retro_gamer', avatarUrl: mockItems[2].owner.avatarUrl },
        lastMessage: { text: 'Sounds good, let\'s do it!', timestamp: '2024-07-21T18:05:00Z', senderUsername: 'alex_swapper' },
        unreadCount: 0,
    },
     {
        id: 'convo3',
        item: { id: 'm7', name: 'Professional DSLR Camera', imageUrl: mockItems[6].imageUrl },
        otherUser: { username: 'pro_snapper', avatarUrl: mockItems[6].owner.avatarUrl },
        lastMessage: { text: 'Can you send more pictures of the sensor?', timestamp: '2024-07-22T10:15:00Z', senderUsername: 'pro_snapper' },
        unreadCount: 0,
    },
];

const mockMessages: { [key: string]: ChatMessage[] } = {
    'convo1': [
        { id: 'msg1-1', conversationId: 'convo1', senderUsername: 'photo_fan', text: 'Is it still available? I have a guitar to trade.', timestamp: '2024-07-22T14:30:00Z' },
    ],
    'convo2': [
        { id: 'msg2-1', conversationId: 'convo2', senderUsername: 'alex_swapper', text: 'Hey, I\'m interested in your retro console. Would you trade for my leather jacket?', timestamp: '2024-07-21T18:00:00Z' },
        { id: 'msg2-2', conversationId: 'convo2', senderUsername: 'retro_gamer', text: 'Hmm, interesting offer. The value is a bit off though.', timestamp: '2024-07-21T18:02:00Z' },
        { id: 'msg2-3', conversationId: 'convo2', senderUsername: 'alex_swapper', text: 'I can add some coins to make it fair.', timestamp: '2024-07-21T18:03:00Z' },
        { id: 'msg2-4', conversationId: 'convo2', senderUsername: 'retro_gamer', text: 'How many coins are we talking?', timestamp: '2024-07-21T18:04:00Z' },
        { id: 'msg2-5', conversationId: 'convo2', senderUsername: 'alex_swapper', text: 'Sounds good, let\'s do it!', timestamp: '2024-07-21T18:05:00Z' },
    ],
    'convo3': [
        { id: 'msg3-1', conversationId: 'convo3', senderUsername: 'pro_snapper', text: 'Can you send more pictures of the sensor?', timestamp: '2024-07-22T10:15:00Z' },
    ],
};

// SIMULATE API LATENCY
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const getMarketplaceItems = async (): Promise<Item[]> => {
    await delay(500);
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    return allItems.filter(item => item.owner.username !== currentUser.username);
};

export const getMockItemsForUser = async (username: string): Promise<Item[]> => {
    await delay(300);
    return allItems.filter(item => item.owner.username === username);
};

export const getMockSwaps = async (username: string): Promise<Swap[]> => {
    await delay(600);
    return mockSwaps.filter(s => s.proposerUsername === username || s.otherUserItem.owner.username === username);
};

export const getMockCoinTransactions = async (username: string): Promise<CoinTransaction[]> => {
    await delay(400);
    return mockTransactions.filter(tx => tx.username === username);
};

export const getMockUserProfile = async (username: string): Promise<UserProfile> => {
    await delay(200);
    const user = MOCK_USERS.find(u => u.username === username);
    if (!user) {
        throw new Error("User not found");
    }
    const { password, ...userProfile } = user;
    return userProfile;
};


export const proposeSwap = async (userItemId: string, otherUserItemId: string, proposer: UserProfile): Promise<Swap> => {
    await delay(1000);
    const userItem = allItems.find(i => i.id === userItemId);
    const otherUserItem = allItems.find(i => i.id === otherUserItemId);

    if (!userItem || !otherUserItem) {
        throw new Error("One or both items not found for the swap.");
    }
    
    const newSwap: Swap = {
        id: `s-${Date.now()}`,
        userItem,
        otherUserItem,
        proposerUsername: proposer.username,
        status: 'Pending',
        date: new Date().toLocaleDateString('en-CA'),
        coinDifference: userItem.value - otherUserItem.value,
    };
    mockSwaps.unshift(newSwap);
    return newSwap;
};

export const respondToSwap = async (swapId: string, response: 'Accepted' | 'Rejected'): Promise<Swap> => {
    await delay(1000);
    const swapIndex = mockSwaps.findIndex(s => s.id === swapId);
    if (swapIndex === -1) {
        throw new Error("Swap not found.");
    }
    
    const swap = mockSwaps[swapIndex];
    if (response === 'Accepted') {
        swap.status = 'Completed'; // For simplicity, we go straight to 'Completed'
        
        // Find users
        const proposer = MOCK_USERS.find(u => u.username === swap.proposerUsername);
        const receiver = MOCK_USERS.find(u => u.username === swap.otherUserItem.owner.username);

        if (proposer && receiver) {
            // 1. Update swap counts
            proposer.swapsCompleted += 1;
            receiver.swapsCompleted += 1;

            // 2. Handle coin difference
            if (swap.coinDifference) {
                if (swap.coinDifference > 0) { // Proposer receives coins from receiver
                    proposer.totalCoinsEarned += swap.coinDifference;
                } else { // Proposer pays coins to receiver
                    receiver.totalCoinsEarned += Math.abs(swap.coinDifference);
                }
            }
             // 3. Swap item ownership
             const originalProposerItemOwner = swap.userItem.owner;
             swap.userItem.owner = swap.otherUserItem.owner;
             swap.otherUserItem.owner = originalProposerItemOwner;
 
             // Update the master list of items
             const userItemIndex = allItems.findIndex(i => i.id === swap.userItem.id);
             const otherUserItemIndex = allItems.findIndex(i => i.id === swap.otherUserItem.id);
             if(userItemIndex > -1) allItems[userItemIndex] = swap.userItem;
             if(otherUserItemIndex > -1) allItems[otherUserItemIndex] = swap.otherUserItem;

             persistUsers();
        }

    } else {
        swap.status = 'Rejected';
    }
    
    mockSwaps[swapIndex] = swap;
    return swap;
};

export const getMockRepairGuidance = async (): Promise<RepairGuidance> => {
    await delay(1200);
    return {
        itemName: "Vintage Polaroid Camera",
        itemImageUrl: mockItems[0].imageUrl,
        detectedIssue: "Film door latch is broken",
        estimatedCost: "150 - 300 Coins",
        isDIYFriendly: true,
        requiredParts: ["Replacement Latch (Part #67B-2)", "Small Phillips screwdriver", "Spudger tool"],
        steps: [
            { id: 'rg1', title: 'Open the Casing', description: 'Carefully pry open the camera casing using the spudger tool near the seam.', completed: false },
            { id: 'rg2', title: 'Remove the Old Latch', description: 'Unscrew the two small screws holding the broken latch mechanism in place.', completed: false },
            { id: 'rg3', title: 'Install New Latch', description: 'Position the new latch and secure it with the screws. Do not overtighten.', completed: false },
            { id: 'rg4', title: 'Reassemble and Test', description: 'Snap the camera casing back together and test the film door to ensure it closes securely.', completed: false },
        ]
    };
};

export const addCoinTransaction = async (transaction: Omit<CoinTransaction, 'id' | 'username'>, username: string): Promise<CoinTransaction> => {
    await delay(300);
    const newTransaction: CoinTransaction = {
        id: `t-${Date.now()}`,
        username: username,
        ...transaction
    };
    mockTransactions.unshift(newTransaction);
    return newTransaction;
}

// MESSAGES API
export const getMockConversations = async (username: string): Promise<ChatConversation[]> => {
    await delay(400);
    // Only return conversations for the mock user 'alex_swapper'
    if (username === 'alex_swapper') {
        return mockConversations;
    }
    return [];
};

export const getMockMessages = async (conversationId: string): Promise<ChatMessage[]> => {
    await delay(250);
    return mockMessages[conversationId] || [];
};

export const sendMockMessage = async (conversationId: string, senderUsername: string, text: string): Promise<ChatMessage> => {
    await delay(200);
    const conversation = mockConversations.find(c => c.id === conversationId);
    if (!conversation) {
        throw new Error("Conversation not found");
    }

    // 1. Create and add the user's message
    const newMessage: ChatMessage = {
        id: `msg-${Date.now()}`,
        conversationId,
        senderUsername,
        text,
        timestamp: new Date().toISOString(),
    };
    if (!mockMessages[conversationId]) {
        mockMessages[conversationId] = [];
    }
    mockMessages[conversationId].push(newMessage);
    conversation.lastMessage = { text, timestamp: newMessage.timestamp, senderUsername };
    
    // 2. Simulate a reply after a delay
    return new Promise(resolve => {
        setTimeout(() => {
            const replyTextOptions = [
                "Okay, got it.",
                "Thanks for letting me know!",
                "That sounds good.",
                "Let me think about that.",
                "Interesting, tell me more."
            ];
            const replyText = replyTextOptions[Math.floor(Math.random() * replyTextOptions.length)];

            const replyMessage: ChatMessage = {
                id: `msg-${Date.now() + 1}`,
                conversationId,
                senderUsername: conversation.otherUser.username,
                text: replyText,
                timestamp: new Date().toISOString(),
            };
            mockMessages[conversationId].push(replyMessage);
            conversation.lastMessage = { text: replyText, timestamp: replyMessage.timestamp, senderUsername: conversation.otherUser.username };
            conversation.unreadCount += 1;

            resolve(newMessage); // Resolve with the original message sent by the user
        }, 1500);
    });
};
