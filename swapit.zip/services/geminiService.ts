import { GoogleGenAI, Type } from "@google/genai";
import type { RepairAnalysisResult, RepairShop } from '../types';

if (!process.env.API_KEY) {
  console.warn("API_KEY is not set. Using a placeholder. AI features will be mocked.");
}

// FIX: Use process.env.API_KEY directly, but keep the fallback for mock mode.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || 'MISSING_API_KEY' });

const repairSchema = {
    type: Type.OBJECT,
    properties: {
        detectedIssue: {
            type: Type.STRING,
            description: "A concise description of the main issue detected with the item."
        },
        repairSummary: {
            type: Type.STRING,
            description: "A brief summary of the repair process and what it entails."
        },
        estimatedCost: {
            type: Type.STRING,
            description: "An estimated cost range for the repair, e.g., '$20 - $30' or 'Under $10'."
        },
        requiredParts: {
            type: Type.ARRAY,
            items: {
                type: Type.STRING,
                description: "A specific part or tool needed for the repair."
            },
            description: "A list of parts or tools required to perform the repair."
        },
        isDIYFriendly: {
            type: Type.BOOLEAN,
            description: "A boolean value indicating if the repair is considered easy enough for a Do-It-Yourself (DIY) approach. True if it is, false if a professional is recommended."
        }
    },
    required: ["detectedIssue", "repairSummary", "estimatedCost", "requiredParts", "isDIYFriendly"]
};

export const getRepairGuidanceFromAI = async (
    prompt: string,
    imageBase64: string,
    mimeType: string
): Promise<RepairAnalysisResult> => {
    // FIX: Use process.env.API_KEY directly for the check.
    if (!process.env.API_KEY) {
        return new Promise(resolve => setTimeout(() => resolve({
            detectedIssue: "Cracked Screen (Demo)",
            repairSummary: "The screen needs to be carefully removed and replaced with a new digitizer assembly. This requires special tools for prying and applying heat.",
            estimatedCost: "$80 - $120",
            requiredParts: ["Replacement Screen Assembly", "Prying tools", "Small Phillips screwdriver", "Heat gun or hair dryer"],
            isDIYFriendly: false
        }), 2000));
    }

    try {
        const imagePart = {
            inlineData: {
                data: imageBase64,
                mimeType: mimeType,
            },
        };

        const textPart = {
            text: `Analyze the provided image and the user's problem description. Based on both, provide a repair assessment. Problem: "${prompt}"`,
        };
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseMimeType: "application/json",
                responseSchema: repairSchema,
            }
        });

        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText) as RepairAnalysisResult;
        return result;

    } catch (error) {
        console.error('Gemini API error:', error);
        throw new Error("Failed to get a response from the AI assistant. Please try again.");
    }
};


export const findNearbyRepairShops = async (
    itemIssue: string,
    latitude: number,
    longitude: number
): Promise<RepairShop[]> => {
    // FIX: Use process.env.API_KEY directly for the check.
    if (!process.env.API_KEY) {
        console.warn("API Key not found, returning mock shop data.");
        return new Promise(resolve => setTimeout(() => resolve([
            { title: "Demo Repair Shop Central", uri: "https://www.google.com/maps" },
            { title: "Alex's Fix-It Garage (Mock)", uri: "https://www.google.com/maps" },
            { title: "Gadget Gurus (Sample)", uri: "https://www.google.com/maps" },
        ]), 1500));
    }

    try {
        const prompt = `Find repair shops for a "${itemIssue}" near latitude ${latitude} and longitude ${longitude}.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{googleSearch: {}}],
            },
        });

        const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (!groundingChunks) {
            return [];
        }
        
        const shops: RepairShop[] = groundingChunks
            .filter((chunk): chunk is { web: { uri: string; title: string } } =>
                Boolean(chunk.web && chunk.web.uri && chunk.web.title)
            )
            .map(chunk => ({
                title: chunk.web.title,
                uri: chunk.web.uri,
            }));
        
        return shops;

    } catch (error) {
        console.error('Gemini API error during shop search:', error);
        throw new Error("Failed to search for nearby shops. Please try again.");
    }
};
