import React, { useState, useEffect, useMemo } from 'react';
import type { UserProfile, Item } from '../types';
import { getMockItemsForUser } from '../services/api';
import { SilverBadgeIcon, GoldBadgeIcon, PlatinumBadgeIcon, TrophyIcon, CoinIcon, PencilIcon, TrashIcon, ItemsIcon, SwapsIcon } from '../components/Icons';
import { useAuth } from '../contexts/AuthContext';

type BadgeLevel = 'None' | 'Silver' | 'Gold' | 'Platinum';
type SortByType = 'newest' | 'value_desc' | 'value_asc';

const categories = ['Electronics', 'Apparel', 'Furniture', 'Collectibles', 'Other'];
const conditions = ['New', 'Used - Like New', 'Used - Good', 'Used - Fair'];

const getBadgeForCoins = (coins: number): { level: BadgeLevel; icon: React.FC<{className?: string}>; color: string; nextTier: number | null } => {
    if (coins >= 10000) return { level: 'Platinum', icon: PlatinumBadgeIcon, color: 'text-slate-400', nextTier: null };
    if (coins >= 5000) return { level: 'Gold', icon: GoldBadgeIcon, color: 'text-yellow-500', nextTier: 10000 };
    if (coins >= 1000) return { level: 'Silver', icon: SilverBadgeIcon, color: 'text-gray-400', nextTier: 5000 };
    return { level: 'None', icon: () => null, color: '', nextTier: 1000 };
};

const Stat: React.FC<{ icon: React.ReactNode; label: string; value: string | number }> = ({ icon, label, value }) => (
    <div className="flex items-center gap-3 text-white">
        <div className="flex-shrink-0">{icon}</div>
        <div>
            <p className="text-sm font-bold">{value}</p>
            <p className="text-xs opacity-80">{label}</p>
        </div>
    </div>
);

const UserStorefrontPage: React.FC = () => {
    const { currentUser: profile } = useAuth();
    const [items, setItems] = useState<Item[]>([]);
    const [selectedCategory, setSelectedCategory] = useState<string>('all');
    const [selectedCondition, setSelectedCondition] = useState<string>('all');
    const [sortBy, setSortBy] = useState<SortByType>('newest');

    useEffect(() => {
        const fetchData = async () => {
            if (profile) {
                const itemsData = await getMockItemsForUser(profile.username);
                setItems(itemsData);
            }
        };
        fetchData();
    }, [profile]);

    const badgeInfo = profile ? getBadgeForCoins(profile.totalCoinsEarned) : null;
    
    const displayedItems = useMemo(() => {
        return items
          .filter(item => {
            const categoryMatch = selectedCategory === 'all' || item.category === selectedCategory;
            const conditionMatch = selectedCondition === 'all' || item.condition === selectedCondition;
            return categoryMatch && conditionMatch;
          })
          .sort((a, b) => {
            switch (sortBy) {
              case 'value_desc': return b.value - a.value;
              case 'value_asc': return a.value - b.value;
              case 'newest':
              default:
                return new Date(b.listedDate).getTime() - new Date(a.listedDate).getTime();
            }
          });
      }, [items, selectedCategory, selectedCondition, sortBy]);

    const selectClass = "bg-white/10 dark:bg-[#001845] border border-white/20 dark:border-gray-700 text-[#001233] dark:text-[#EFEFDE] rounded-lg text-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#2A67C9] transition-colors";

    if (!profile || !badgeInfo) {
        return (
            <div className="flex justify-center items-center h-full">
                <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-[#2A67C9]"></div>
            </div>
        );
    }
    
    return (
        <div className="animate-fadeIn space-y-8">
            {/* Banner Section */}
            <div className="relative bg-gradient-to-r from-[#001233] to-[#2A67C9] dark:from-[#001233] dark:to-[#001845] rounded-lg p-6 md:p-8 shadow-lg overflow-hidden">
                 <div className="absolute inset-0 bg-cover bg-center opacity-10" style={{backgroundImage: "url('https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?&auto=format&fit=crop&w=1200&q=80')"}}></div>
                <div className="relative flex flex-col md:flex-row items-center gap-6">
                    <img
                        src={profile.avatarUrl}
                        alt={profile.name}
                        className="w-28 h-28 md:w-32 md:h-32 rounded-full border-4 border-white/50 dark:border-[#E9D8A6] object-cover flex-shrink-0"
                    />
                    <div className="flex-1 text-center md:text-left">
                        <h1 className="text-3xl font-bold text-white">{profile.name}</h1>
                        <p className="text-gray-300 dark:text-gray-400">@{profile.username}</p>
                        <div className="mt-4 flex flex-wrap justify-center md:justify-start items-center gap-x-6 gap-y-2">
                           <Stat icon={<ItemsIcon className="w-5 h-5 opacity-80" />} label="Items Listed" value={profile.itemsListed} />
                           <Stat icon={<SwapsIcon className="w-5 h-5 opacity-80" />} label="Swaps Completed" value={profile.swapsCompleted} />
                           <p className="text-xs text-white/70">Member since {profile.memberSince}</p>
                        </div>
                    </div>
                </div>
            </div>
            
            {/* Badges and Items Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1">
                     <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col items-center text-center sticky top-8">
                        <TrophyIcon className="w-8 h-8 text-[#EE9B00] mb-2" />
                        <h3 className="text-lg font-bold text-[#001233] dark:text-[#EFEFDE]">Your Badge</h3>
                        {badgeInfo.level !== 'None' ? (
                            <>
                                <badgeInfo.icon className="w-20 h-20 my-2" />
                                <p className={`text-xl font-bold ${badgeInfo.color}`}>{badgeInfo.level}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                                    {profile.totalCoinsEarned.toLocaleString()} coins earned
                                </p>
                                {badgeInfo.nextTier && (
                                    <div className="w-full mt-3">
                                        <p className="text-xs text-center text-gray-500 dark:text-gray-400 mb-1">
                                            {badgeInfo.nextTier - profile.totalCoinsEarned} coins to next tier
                                        </p>
                                        <div className="w-full bg-gray-200 dark:bg-[#001845] rounded-full h-2">
                                            <div className="bg-[#2A67C9] h-2 rounded-full" style={{ width: `${(profile.totalCoinsEarned / badgeInfo.nextTier) * 100}%` }}></div>
                                        </div>
                                    </div>
                                )}
                            </>
                        ) : (
                             <div className="text-center py-4">
                                <p className="text-gray-500">No badge yet. Keep swapping!</p>
                             </div>
                        )}
                    </div>
                </div>
                <div className="lg:col-span-2">
                    <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                             <h2 className="text-2xl font-bold text-[#001233] dark:text-[#EFEFDE]">My Items ({items.length})</h2>
                             <div className="flex items-center gap-2">
                                <select value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)} className={selectClass.replace('text-white', 'text-gray-700 dark:text-gray-300')}>
                                    <option value="all">All Categories</option>
                                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                                <select value={sortBy} onChange={e => setSortBy(e.target.value as SortByType)} className={selectClass.replace('text-white', 'text-gray-700 dark:text-gray-300')}>
                                    <option value="newest">Newest</option>
                                    <option value="value_desc">Highest Value</option>
                                    <option value="value_asc">Lowest Value</option>
                                </select>
                             </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                           {displayedItems.map(item => (
                             <div key={item.id} className="bg-gray-50 dark:bg-[#001845] rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 group flex flex-col">
                               <img src={item.imageUrl} alt={item.name} className="w-full h-40 object-cover" />
                               <div className="p-4 flex flex-col flex-grow">
                                 <h3 className="font-bold text-[#001233] dark:text-[#EFEFDE] truncate">{item.name}</h3>
                                 <p className="text-xs text-gray-500 dark:text-gray-400">{item.condition}</p>
                                 <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                                   <div className="flex items-center gap-1 font-bold text-[#EE9B00] dark:text-[#E9D8A6]">
                                     <CoinIcon className="w-5 h-5" />
                                     <span>{item.value.toLocaleString()}</span>
                                   </div>
                                   <div className="flex items-center gap-2">
                                       <button className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-[#001233] transition-colors" aria-label="Edit item">
                                            <PencilIcon className="w-4 h-4 text-gray-600 dark:text-gray-300"/>
                                       </button>
                                       <button className="p-2 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50 transition-colors" aria-label="Delete item">
                                            <TrashIcon className="w-4 h-4 text-red-600 dark:text-red-400"/>
                                       </button>
                                   </div>
                                 </div>
                               </div>
                             </div>
                           ))}
                        </div>
                         {displayedItems.length === 0 && (
                            <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                                <p>You haven't listed any items with these filters.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UserStorefrontPage;
