import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { SilverBadgeIcon, GoldBadgeIcon, PlatinumBadgeIcon, BronzeBadgeIcon } from '../components/Icons';
import type { Badge } from '../types';

const BadgeIcon: React.FC<{ badge: Badge, className?: string }> = ({ badge, className }) => {
    switch (badge) {
        case 'Bronze': return <BronzeBadgeIcon className={className} />;
        case 'Silver': return <SilverBadgeIcon className={className} />;
        case 'Gold': return <GoldBadgeIcon className={className} />;
        case 'Platinum': return <PlatinumBadgeIcon className={className} />;
        default: return null;
    }
};

const ProfilePage: React.FC = () => {
    const { currentUser } = useAuth();
    
    // For a real app, you would have state and handlers for editing.
    // Here we'll just display the data from the context.
    const [isEditing, setIsEditing] = useState(false);
    
    // Mock editable state
    const [name, setName] = useState(currentUser?.name || '');
    const [username, setUsername] = useState(currentUser?.username || '');
    const [location, setLocation] = useState(currentUser?.location || '');
    const [dob, setDob] = useState(currentUser?.dob || '');

    if (!currentUser) {
        return (
            <div className="flex justify-center items-center h-full">
                <p>Loading profile...</p>
            </div>
        );
    }
    
    const handleSave = () => {
        // In a real app, this would call an API to update the user profile.
        console.log("Saving profile:", { name, username, location, dob });
        setIsEditing(false);
    };

    return (
        <div className="animate-fadeIn">
            <h1 className="text-3xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-8">Your Profile</h1>
            
            <div className="bg-white dark:bg-[#001233] p-6 md:p-8 rounded-lg border border-gray-200 dark:border-gray-700 max-w-4xl mx-auto">
                <div className="flex flex-col md:flex-row items-center gap-8">
                    <div className="relative flex-shrink-0">
                        <img src={currentUser.avatarUrl} alt={currentUser.name} className="w-32 h-32 rounded-full object-cover border-4 border-[#2A67C9]/50" />
                        <div className="absolute -bottom-2 -right-2">
                             <BadgeIcon badge={currentUser.badge} className="w-12 h-12" />
                        </div>
                    </div>
                    <div className="flex-1 w-full">
                         <div className="flex justify-between items-center mb-4">
                            <h2 className="text-2xl font-bold text-[#001233] dark:text-[#EFEFDE]">{isEditing ? "Edit Profile" : "Profile Details"}</h2>
                            {isEditing ? (
                                <div className="flex gap-2">
                                     <button onClick={() => setIsEditing(false)} className="text-sm font-semibold text-gray-600 dark:text-gray-300 py-1 px-3 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">Cancel</button>
                                     <button onClick={handleSave} className="text-sm font-semibold bg-[#2A67C9] text-white py-1 px-3 rounded-md hover:bg-[#255ab5]">Save</button>
                                </div>
                            ) : (
                                <button onClick={() => setIsEditing(true)} className="text-sm font-semibold text-[#2A67C9] dark:text-[#E9D8A6] hover:underline">Edit Profile</button>
                            )}
                         </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                            <div>
                                <label className="text-xs text-gray-500 dark:text-gray-400">Full Name</label>
                                {isEditing ? <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="w-full bg-gray-100 dark:bg-[#001845] p-2 rounded-md" /> : <p className="font-semibold text-lg">{currentUser.name}</p>}
                            </div>
                             <div>
                                <label className="text-xs text-gray-500 dark:text-gray-400">Username</label>
                                {isEditing ? <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} className="w-full bg-gray-100 dark:bg-[#001845] p-2 rounded-md" /> : <p className="font-semibold text-lg">@{currentUser.username}</p>}
                            </div>
                            <div>
                                <label className="text-xs text-gray-500 dark:text-gray-400">Location</label>
                                {isEditing ? <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} className="w-full bg-gray-100 dark:bg-[#001845] p-2 rounded-md" /> : <p className="font-semibold text-lg">{currentUser.location}</p>}
                            </div>
                            <div>
                                <label className="text-xs text-gray-500 dark:text-gray-400">Date of Birth</label>
                                {isEditing ? <input type="date" value={dob} onChange={(e) => setDob(e.target.value)} className="w-full bg-gray-100 dark:bg-[#001845] p-2 rounded-md" /> : <p className="font-semibold text-lg">{new Date(currentUser.dob).toLocaleDateString()}</p>}
                            </div>
                            <div>
                                <label className="text-xs text-gray-500 dark:text-gray-400">Member Since</label>
                                <p className="font-semibold text-lg">{currentUser.memberSince}</p>
                            </div>
                        </div>
                    </div>
                </div>
                 <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                    <div>
                        <p className="text-2xl font-bold text-[#2A67C9]">{currentUser.itemsListed}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Items Listed</p>
                    </div>
                    <div>
                        <p className="text-2xl font-bold text-[#2A67C9]">{currentUser.swapsCompleted}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Swaps Completed</p>
                    </div>
                     <div>
                        <p className="text-2xl font-bold text-[#2A67C9]">{currentUser.totalCoinsEarned.toLocaleString()}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Total Coins Earned</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;