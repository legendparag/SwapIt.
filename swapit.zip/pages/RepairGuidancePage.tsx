import React, { useState, useEffect } from 'react';
import type { RepairGuidance, RepairStep } from '../types';
import { getMockRepairGuidance } from '../services/api';
import { DollarSignIcon, UserCheckIcon, WrenchIcon, CheckCircleIcon, MapPinIcon } from '../components/Icons';

const RepairGuidancePage: React.FC = () => {
  const [guidance, setGuidance] = useState<RepairGuidance | null>(null);
  const [steps, setSteps] = useState<RepairStep[]>([]);

  useEffect(() => {
    const fetchGuidance = async () => {
      const mockGuidance = await getMockRepairGuidance();
      setGuidance(mockGuidance);
      setSteps(mockGuidance.steps);
    };
    fetchGuidance();
  }, []);

  const handleToggleStep = (stepId: string) => {
    setSteps(prevSteps =>
      prevSteps.map(step =>
        step.id === stepId ? { ...step, completed: !step.completed } : step
      )
    );
  };

  const InfoCard: React.FC<{ icon: React.ReactNode; label: string; children: React.ReactNode; }> = ({ icon, label, children }) => (
    <div className="flex items-start gap-4">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#2A67C9]/10 dark:bg-[#2A67C9]/20 flex items-center justify-center">
          {icon}
      </div>
      <div>
        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</p>
        <div className="text-[#001233] dark:text-[#EFEFDE] font-bold text-base">{children}</div>
      </div>
    </div>
  );

  if (!guidance) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-[#2A67C9]"></div>
      </div>
    );
  }

  return (
    <div className="animate-fadeIn">
      <h1 className="text-3xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-2">Repair Guidance</h1>
      <p className="text-[#001233] dark:text-[#EFEFDE] mb-8">Follow these steps to get your item back in working order.</p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Main Content */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row items-start gap-6">
            <img src={guidance.itemImageUrl} alt={guidance.itemName} className="w-full sm:w-40 h-40 object-cover rounded-lg flex-shrink-0"/>
            <div>
                <h2 className="text-2xl font-bold text-[#001233] dark:text-[#EFEFDE]">{guidance.itemName}</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">Detected Issue:</p>
                <p className="text-lg font-semibold text-[#EE9B00] dark:text-red-400">{guidance.detectedIssue}</p>
            </div>
          </div>

          <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700">
            <h3 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-4">Repair Steps</h3>
            <div className="space-y-4">
                {steps.map((step, index) => (
                    <div key={step.id} onClick={() => handleToggleStep(step.id)} className="flex items-start gap-4 p-4 rounded-lg cursor-pointer transition-colors hover:bg-gray-50 dark:hover:bg-[#001845]">
                        <CheckCircleIcon completed={step.completed} className={`w-6 h-6 flex-shrink-0 mt-0.5 transition-colors ${step.completed ? 'text-green-500' : 'text-gray-300 dark:text-gray-500'}`} />
                        <div className={`transition-opacity ${step.completed ? 'opacity-60' : 'opacity-100'}`}>
                            <h4 className={`font-bold text-[#001233] dark:text-[#EFEFDE] ${step.completed ? 'line-through' : ''}`}>Step {index + 1}: {step.title}</h4>
                            <p className={`text-sm text-[#001233] dark:text-[#EFEFDE] ${step.completed ? 'line-through' : ''}`}>{step.description}</p>
                        </div>
                    </div>
                ))}
            </div>
          </div>
        </div>

        {/* Right Column: Overview Card */}
        <div className="lg:col-span-1">
            <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700 sticky top-8">
                <h3 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-6">Repair Overview</h3>
                <div className="space-y-6">
                    <InfoCard icon={<DollarSignIcon className="w-5 h-5 text-[#2A67C9]" />} label="Estimated Cost">
                        {guidance.estimatedCost}
                    </InfoCard>
                    <InfoCard icon={<UserCheckIcon className="w-5 h-5 text-[#2A67C9]" />} label="DIY Friendly?">
                        <span className={guidance.isDIYFriendly ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                            {guidance.isDIYFriendly ? "Yes" : "No, professional recommended"}
                        </span>
                    </InfoCard>
                    <InfoCard icon={<WrenchIcon className="w-5 h-5 text-[#2A67C9]" />} label="Required Parts">
                        <ul className="list-disc list-inside space-y-1 mt-1 font-normal">
                           {guidance.requiredParts.map(part => <li key={part}>{part}</li>)}
                        </ul>
                    </InfoCard>
                </div>
                <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <button className="w-full bg-[#2A67C9] text-white font-bold py-3 px-4 rounded-lg hover:bg-[#255ab5] transition-colors flex items-center justify-center gap-2">
                        <MapPinIcon className="w-5 h-5" />
                        Find Nearby Repair Shops
                    </button>
                    <p className="text-xs text-center mt-3 text-gray-400 dark:text-gray-500">(Feature coming soon)</p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default RepairGuidancePage;