import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CoinIcon } from '../components/Icons';

const PaymentOption: React.FC<{ id: string, label: string, selected: boolean, onSelect: () => void }> = ({ id, label, selected, onSelect }) => (
    <label htmlFor={id} className={`flex items-center p-4 border rounded-lg cursor-pointer transition-all ${selected ? 'bg-[#2A67C9]/10 border-[#2A67C9] dark:bg-[#2A67C9]/20' : 'border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800/30'}`}>
        <input type="radio" id={id} name="paymentOption" checked={selected} onChange={onSelect} className="w-4 h-4 text-[#2A67C9] focus:ring-[#2A67C9]" />
        <span className="ml-3 font-semibold text-[#001233] dark:text-[#EFEFDE]">{label}</span>
    </label>
);

const PaymentGatewayPage: React.FC = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const { amount } = location.state || { amount: 0 };

    const [selectedOption, setSelectedOption] = useState('card');
    const [isProcessing, setIsProcessing] = useState(false);

    if (amount === 0) {
        navigate('/wallet', { replace: true });
        return null;
    }

    const handlePayment = (e: React.FormEvent) => {
        e.preventDefault();
        setIsProcessing(true);
        setTimeout(() => {
            navigate('/payment-success', { state: { amount }, replace: true });
        }, 2000);
    };

    return (
        <div className="flex items-center justify-center min-h-full p-4">
            <div className="w-full max-w-lg bg-white dark:bg-[#001233] p-8 rounded-lg border border-gray-200 dark:border-gray-700 shadow-xl animate-fadeIn">
                <h1 className="text-2xl font-bold text-center text-[#001233] dark:text-[#EFEFDE] mb-2">Complete Your Purchase</h1>
                <p className="text-center text-gray-500 dark:text-gray-400 mb-6">You're just one step away from getting your coins!</p>
                
                <div className="bg-gray-100 dark:bg-[#001845] p-4 rounded-lg mb-6 border border-gray-200 dark:border-gray-700">
                    <h2 className="font-semibold text-lg text-[#001233] dark:text-[#EFEFDE]">Order Summary</h2>
                    <div className="flex justify-between items-center mt-2">
                        <div className="flex items-center gap-2">
                            <CoinIcon className="w-6 h-6 text-[#EE9B00]" />
                            <span className="text-gray-700 dark:text-gray-300">{amount.toLocaleString()} SwapCoins</span>
                        </div>
                        <span className="font-bold text-lg text-[#001233] dark:text-[#EFEFDE]">₹{amount.toLocaleString()}</span>
                    </div>
                </div>

                <form onSubmit={handlePayment} className="space-y-4">
                    <h2 className="font-semibold text-lg text-[#001233] dark:text-[#EFEFDE]">Select Payment Method</h2>
                    <div className="space-y-3">
                       <PaymentOption id="card" label="Credit/Debit Card" selected={selectedOption === 'card'} onSelect={() => setSelectedOption('card')} />
                       <PaymentOption id="upi" label="UPI / QR" selected={selectedOption === 'upi'} onSelect={() => setSelectedOption('upi')} />
                       <PaymentOption id="netbanking" label="Net Banking" selected={selectedOption === 'netbanking'} onSelect={() => setSelectedOption('netbanking')} />
                    </div>

                    <div className="pt-4">
                        <button
                            type="submit"
                            disabled={isProcessing}
                            className="w-full bg-[#2A67C9] text-white font-bold py-3 px-4 rounded-lg hover:bg-[#255ab5] transition-colors flex items-center justify-center disabled:bg-[#2A67C9]/50 disabled:cursor-wait"
                        >
                            {isProcessing ? (
                                <>
                                  <div className="w-5 h-5 border-2 border-dashed rounded-full animate-spin border-white mr-2"></div>
                                  Processing...
                                </>
                            ) : (
                                `Pay ₹${amount.toLocaleString()}`
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default PaymentGatewayPage;