import React, { useState } from 'react';
import { UploadIcon, TagIcon, AlertTriangleIcon, WrenchIcon, DollarSignIcon, UserCheckIcon, CoinIcon } from '../components/Icons';

type AnalysisResult = {
  value: string; // Changed from price to value
  faults: string[];
  repairs: string[];
  repairCost: string;
  professionalRequired: boolean;
};

const UploadItemPage: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  
  const [productName, setProductName] = useState('');
  const [category, setCategory] = useState('');
  const [condition, setCondition] = useState('');

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [errors, setErrors] = useState({
    image: '',
    productName: '',
    category: '',
    condition: '',
  });

  const handleFile = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setAnalysisResult(null); // Reset analysis when new image is uploaded
      if (errors.image) {
        setErrors(prev => ({...prev, image: ''}));
      }
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };
  
  const validate = (): boolean => {
    const newErrors = { image: '', productName: '', category: '', condition: ''};
    let isValid = true;

    if (!imageFile) {
        newErrors.image = 'An image of the item is required.';
        isValid = false;
    }
    if (!productName.trim()) {
        newErrors.productName = 'Product name cannot be empty.';
        isValid = false;
    }
    if (!category) {
        newErrors.category = 'Please select a category.';
        isValid = false;
    }
    if (!condition) {
        newErrors.condition = 'Please select the item condition.';
        isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleAnalyze = () => {
    if (validate()) {
      setIsAnalyzing(true);
      setAnalysisResult(null);
      
      // Simulate AI analysis
      const timer = setTimeout(() => {
        setAnalysisResult({
          value: '1500 - 1800',
          faults: ['Minor scratches on screen', 'Worn-out battery'],
          repairs: ['Screen polishing', 'Battery replacement'],
          repairCost: '250',
          professionalRequired: false,
        });
        setIsAnalyzing(false);
      }, 2500);

      // No cleanup needed as it's a one-off action in a component that won't unmount
    }
  };

  const inputClasses = "w-full bg-gray-50 dark:bg-[#001845] text-[#001233] dark:text-[#EFEFDE] rounded-lg px-4 py-2 focus:outline-none focus:ring-2 border border-gray-200 dark:border-gray-600";
  const selectClasses = `${inputClasses} appearance-none`;

  const AnalysisItem: React.FC<{ icon: React.ReactNode; label: string; value: string | string[]; color?: string; isCoin?: boolean }> = ({ icon, label, value, color = 'text-[#001233] dark:text-[#EFEFDE]', isCoin = false }) => (
    <div className="flex items-start gap-4">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#2A67C9]/10 dark:bg-[#2A67C9]/20 flex items-center justify-center">
        {icon}
      </div>
      <div>
        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</p>
        {Array.isArray(value) ? (
          <ul className="list-disc list-inside space-y-1 mt-1">
            {value.map((item, index) => (
              <li key={index} className={`text-base font-semibold ${color}`}>{item}</li>
            ))}
          </ul>
        ) : (
          <div className={`flex items-center gap-2 text-lg font-bold ${color}`}>
            <span>{value}</span>
            {isCoin && <CoinIcon className="w-5 h-5 text-[#EE9B00]" />}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="animate-fadeIn">
      <h1 className="text-3xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-2">Add Your Item</h1>
      <p className="text-[#001233] dark:text-[#EFEFDE] mb-8">Upload an image and details to get an AI-powered valuation.</p>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column: Upload & Form */}
        <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700 space-y-6">
          <div>
            <label htmlFor="file-upload" className="cursor-pointer">
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`relative w-full h-64 border-2 border-dashed rounded-lg flex flex-col items-center justify-center transition-colors duration-300 ${
                  isDragging ? 'border-[#2A67C9] bg-[#2A67C9]/10' : (errors.image ? 'border-red-500' : 'border-gray-300 dark:border-gray-600 hover:border-[#2A67C9]')
                }`}
              >
                <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*" />
                {imagePreview ? (
                  <img src={imagePreview} alt="Product Preview" className="absolute inset-0 w-full h-full object-cover rounded-lg" />
                ) : (
                  <div className="text-center text-[#001233] dark:text-[#EFEFDE]">
                    <UploadIcon className="mx-auto h-12 w-12" />
                    <p className="mt-2 font-semibold">Drag & drop an image here</p>
                    <p className="text-sm">or click to upload</p>
                    <p className="text-xs mt-1 text-gray-500">PNG, JPG up to 10MB</p>
                  </div>
                )}
              </div>
            </label>
            {errors.image && <p className="text-red-500 text-xs mt-1">{errors.image}</p>}
          </div>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="productName" className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Product Name</label>
              <input type="text" id="productName" value={productName} 
                onChange={e => { 
                    setProductName(e.target.value); 
                    setAnalysisResult(null);
                    if(errors.productName) setErrors(prev => ({ ...prev, productName: '' }));
                }} 
                className={`${inputClasses} ${errors.productName ? 'border-red-500 focus:ring-red-500' : 'focus:ring-[#2A67C9]'}`} placeholder="e.g., Vintage Leather Jacket" />
              {errors.productName && <p className="text-red-500 text-xs mt-1">{errors.productName}</p>}
            </div>
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Category</label>
              <select id="category" value={category} 
                onChange={e => { 
                    setCategory(e.target.value); 
                    setAnalysisResult(null);
                    if(errors.category) setErrors(prev => ({ ...prev, category: '' }));
                }} 
                className={`${selectClasses} ${errors.category ? 'border-red-500 focus:ring-red-500' : 'focus:ring-[#2A67C9]'}`}>
                <option value="" disabled>Select a category</option>
                <option>Electronics</option>
                <option>Apparel</option>
                <option>Furniture</option>
                <option>Collectibles</option>
                <option>Other</option>
              </select>
              {errors.category && <p className="text-red-500 text-xs mt-1">{errors.category}</p>}
            </div>
            <div>
              <label htmlFor="condition" className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Condition</label>
              <select id="condition" value={condition} 
                onChange={e => { 
                    setCondition(e.target.value); 
                    setAnalysisResult(null);
                    if(errors.condition) setErrors(prev => ({ ...prev, condition: '' }));
                }} 
                className={`${selectClasses} ${errors.condition ? 'border-red-500 focus:ring-red-500' : 'focus:ring-[#2A67C9]'}`}>
                <option value="" disabled>Select condition</option>
                <option>New</option>
                <option>Used - Like New</option>
                <option>Used - Good</option>
                <option>Used - Fair</option>
              </select>
              {errors.condition && <p className="text-red-500 text-xs mt-1">{errors.condition}</p>}
            </div>
          </div>
        </div>

        {/* Right Column: AI Analysis */}
        <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col">
          <h2 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-4">AI Analysis</h2>
          <div className="flex-grow flex flex-col justify-between">
            {isAnalyzing ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-4">
                  <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-[#2A67C9]"></div>
                  <p className="mt-4 text-[#001233] dark:text-[#EFEFDE]">Analyzing your item...</p>
              </div>
            ) : analysisResult ? (
              <div className="flex flex-col justify-between h-full">
                <div className="space-y-6 animate-fadeIn">
                    <AnalysisItem icon={<TagIcon className="w-5 h-5 text-[#2A67C9]" />} label="Estimated Value" value={analysisResult.value} isCoin={true} color="text-[#EE9B00] dark:text-[#E9D8A6]" />
                    <AnalysisItem icon={<AlertTriangleIcon className="w-5 h-5 text-[#2A67C9]" />} label="Faults Detected" value={analysisResult.faults} />
                    <AnalysisItem icon={<WrenchIcon className="w-5 h-5 text-[#2A67C9]" />} label="Required Repairs" value={analysisResult.repairs} />
                    <AnalysisItem icon={<DollarSignIcon className="w-5 h-5 text-[#2A67C9]" />} label="Estimated Repair Cost" value={analysisResult.repairCost} isCoin={true} />
                    <AnalysisItem 
                      icon={<UserCheckIcon className="w-5 h-5 text-[#2A67C9]" />} 
                      label="Professional Required" 
                      value={analysisResult.professionalRequired ? "Yes" : "No"} 
                      color={analysisResult.professionalRequired ? 'text-red-500 dark:text-red-400' : 'text-green-600 dark:text-green-400'}
                    />
                </div>
                <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <button className="w-full bg-[#2A67C9] text-white font-bold py-3 px-4 rounded-lg hover:bg-[#255ab5] transition-colors">
                        Add Item & Proceed to Swap
                    </button>
                </div>
              </div>
            ) : (
                <div className="h-full flex flex-col justify-between">
                    <div className="text-center text-gray-500 dark:text-gray-400 p-4 flex-grow flex items-center justify-center">
                        <p>Fill out all fields and click "Analyze" to get an AI-powered valuation for your item.</p>
                    </div>
                    <div>
                         <button 
                            onClick={handleAnalyze} 
                            className="w-full bg-[#001233] text-white dark:text-[#EFEFDE] font-bold py-3 px-4 rounded-lg hover:bg-black/80 dark:hover:bg-[#001845] transition-colors flex items-center justify-center gap-2"
                        >
                            <TagIcon className="w-5 h-5" />
                            Analyze Item
                        </button>
                    </div>
                </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UploadItemPage;