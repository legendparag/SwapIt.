import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CoinIcon, ArrowUpCircleIcon, ArrowDownCircleIcon, ClockIcon, PlusIcon, TrophyIcon } from '../components/Icons';
import { getMockCoinTransactions } from '../services/api';
import type { CoinTransaction } from '../types';
import { useAuth } from '../contexts/AuthContext';

const WalletPage: React.FC = () => {
  const [transactions, setTransactions] = useState<CoinTransaction[]>([]);
  const [expiringSoon, setExpiringSoon] = useState<{ amount: number, days: number } | null>(null);
  const [isAddCoinsModalOpen, setIsAddCoinsModalOpen] = useState(false);
  const [amountToAdd, setAmountToAdd] = useState('');
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const calculateExpiry = (txs: CoinTransaction[]) => {
    const now = new Date();
    
    // Filter for EARNED credits that have not expired yet
    const unexpiredEarnedCredits = txs
      .filter(tx => tx.type === 'Credit' && tx.source === 'earned' && new Date(tx.expiryDate) > now)
      .map(tx => ({ ...tx, expiry: new Date(tx.expiryDate) }))
      .sort((a, b) => a.expiry.getTime() - b.expiry.getTime());

    if (unexpiredEarnedCredits.length > 0) {
      const oldestCredit = unexpiredEarnedCredits[0];
      const diffTime = oldestCredit.expiry.getTime() - now.getTime();
      const diffDays = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
      setExpiringSoon({ amount: oldestCredit.amount, days: diffDays });
    } else {
        setExpiringSoon(null);
    }
  };

  useEffect(() => {
    const fetchTransactions = async () => {
      if (!currentUser) return;
      const mockTransactions = await getMockCoinTransactions(currentUser.username);
      const chronologicalTransactions = mockTransactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setTransactions(chronologicalTransactions);
    };
    fetchTransactions();
  }, [currentUser]);

  useEffect(() => {
    if (transactions.length > 0) {
      calculateExpiry(transactions);
    }
  }, [transactions]);
  
  const handleAddCoins = () => {
    const amount = parseInt(amountToAdd, 10);
    if (isNaN(amount) || amount <= 0) return;

    navigate('/payment-gateway', { state: { amount } });
    setIsAddCoinsModalOpen(false);
    setAmountToAdd('');
  };

  const earnedCoins = transactions.filter(t => t.source === 'earned' || t.source === 'bonus').reduce((acc, tx) => acc + (tx.type === 'Credit' ? tx.amount : -Math.abs(tx.amount)), 0);
  const purchasedCoins = transactions.filter(t => t.source === 'purchased').reduce((acc, tx) => acc + (tx.type === 'Credit' ? tx.amount : -Math.abs(tx.amount)), 0);
  const balance = transactions.reduce((acc, tx) => acc + (tx.type === 'Credit' ? tx.amount : -Math.abs(tx.amount)), 0);

  // Find the maximum absolute transaction amount to scale the bars for the chart
  const maxAmount = Math.max(...transactions.map(tx => Math.abs(tx.amount)), 1); // Avoid division by zero

  return (
    <div className="animate-fadeIn">
      <div className="flex justify-between items-center mb-8 flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold text-[#001233] dark:text-[#EFEFDE]">Wallet</h1>
          <p className="text-[#001233] dark:text-[#EFEFDE]">Your SwapCoin balance and transaction history.</p>
        </div>
        <button
          onClick={() => setIsAddCoinsModalOpen(true)}
          className="bg-[#2A67C9] text-white font-bold py-2 px-4 rounded-lg hover:bg-[#255ab5] transition-colors flex items-center justify-center"
        >
          <PlusIcon className="w-5 h-5 mr-2" />
          Add Coins
        </button>
      </div>
      
      <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Balance</h3>
            <div className="flex items-center mt-2">
              <CoinIcon className="w-10 h-10 text-[#EE9B00] mr-3" />
              <p className="text-4xl font-bold text-[#001233] dark:text-[#EFEFDE]">{balance.toLocaleString()}</p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 flex divide-x dark:divide-gray-700">
            <div className="pr-4 w-1/2">
                <p className="text-xs text-gray-500 dark:text-gray-400">Earned Coins</p>
                <p className="text-lg font-semibold text-green-600 dark:text-green-400">{earnedCoins.toLocaleString()}</p>
            </div>
            <div className="pl-4 w-1/2">
                <p className="text-xs text-gray-500 dark:text-gray-400">Purchased Coins</p>
                <p className="text-lg font-semibold text-sky-600 dark:text-sky-400">{purchasedCoins.toLocaleString()}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Earned Coin Expiry</h3>
            {expiringSoon && expiringSoon.days <= 30 ? (
                <div className="flex items-center mt-2">
                    <ClockIcon className="w-10 h-10 text-red-500 mr-3" />
                    <div>
                        <p className="text-2xl font-bold text-[#001233] dark:text-[#EFEFDE]">
                            <span className="text-red-500">{expiringSoon.amount.toLocaleString()} coins</span> expire in
                        </p>
                        <p className="text-lg font-semibold text-[#001233] dark:text-[#EFEFDE]">{expiringSoon.days} day{expiringSoon.days !== 1 && 's'}</p>
                    </div>
                </div>
            ) : (
                <div className="flex items-center mt-2">
                     <ClockIcon className="w-10 h-10 text-gray-400 mr-3" />
                     <p className="text-lg text-gray-500 dark:text-gray-400">No earned coins expiring soon.</p>
                </div>
            )}
            <p className="text-xs text-gray-400 mt-2">Purchased coins expire in 90 days.</p>
        </div>
      </div>

      <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700">
        <h2 className="text-xl font-semibold text-[#001233] dark:text-[#EFEFDE] mb-4">Transaction Overview</h2>

        <div className="h-40 flex items-end gap-2 border-b-2 border-gray-200 dark:border-gray-700 pb-2 mb-4">
            {[...transactions].slice(0, 30).reverse().map((tx) => (
                <div key={tx.id} className="flex-1 h-full flex items-end group relative">
                    <div
                        className={`w-full rounded-t-sm transition-all duration-300 ${tx.type === 'Credit' ? 'bg-green-400 hover:bg-green-500' : 'bg-red-400 hover:bg-red-500'}`}
                        style={{ height: `${(Math.abs(tx.amount) / maxAmount) * 100}%` }}
                        title={`${tx.description}: ${tx.type === 'Credit' ? '+' : ''}${tx.amount.toLocaleString()}`}
                    ></div>
                    <div className="absolute bottom-full mb-2 w-max max-w-xs bg-black text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none left-1/2 -translate-x-1/2">
                      {tx.description}<br/>
                      <span className="font-bold">{tx.type === 'Credit' ? '+' : ''}{tx.amount.toLocaleString()} coins</span>
                    </div>
                </div>
            ))}
        </div>

        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-transparent">
                    <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Transaction</th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Amount</th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Date</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {transactions.map(tx => (
                        <tr key={tx.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                    {tx.type === 'Credit' ? (
                                        <ArrowUpCircleIcon className="w-6 h-6 text-green-500 mr-3"/>
                                    ) : (
                                        <ArrowDownCircleIcon className="w-6 h-6 text-red-500 mr-3"/>
                                    )}
                                    <div>
                                        <div className="text-sm font-medium text-[#001233] dark:text-[#EFEFDE]">{tx.description}</div>
                                        <div className={`text-xs px-1.5 py-0.5 rounded-full inline-block mt-1 ${tx.source === 'earned' || tx.source === 'bonus' ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' : 'bg-sky-100 text-sky-800 dark:bg-sky-900/50 dark:text-sky-300'}`}>
                                            {tx.source}
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td className={`px-6 py-4 whitespace-nowrap text-right text-sm font-semibold ${tx.type === 'Credit' ? 'text-green-600' : 'text-red-600'}`}>
                                {tx.type === 'Credit' ? '+' : ''}{tx.amount.toLocaleString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500 dark:text-gray-400">{tx.date}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      </div>

      {isAddCoinsModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 animate-fadeIn">
            <div className="bg-white dark:bg-[#001233] rounded-lg shadow-xl w-full max-w-md p-6 border border-gray-200 dark:border-gray-700">
                <h2 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-2">Purchase SwapCoins</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Coins are used to balance swaps. ₹1 = 1 Coin.</p>
                
                <div className="relative my-4">
                    <input 
                        type="number"
                        value={amountToAdd}
                        onChange={(e) => setAmountToAdd(e.target.value)}
                        placeholder="Enter amount"
                        className="w-full bg-gray-100 dark:bg-[#001845] text-[#001233] dark:text-[#EFEFDE] rounded-md py-3 pl-10 pr-4 text-lg focus:outline-none focus:ring-2 focus:ring-[#2A67C9]"
                    />
                    <CoinIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 text-[#EE9B00]" />
                </div>

                <div className="flex justify-center gap-2 mb-4">
                    {[100, 500, 1000].map(amount => (
                        <button key={amount} onClick={() => setAmountToAdd(String(amount))} className="border border-gray-300 dark:border-gray-600 text-[#001233] dark:text-[#EFEFDE] font-semibold py-1 px-4 rounded-full hover:bg-gray-100 dark:hover:bg-[#001845] transition-colors">
                            {amount}
                        </button>
                    ))}
                </div>

                <div className="text-center text-sm text-gray-500 dark:text-gray-400 mb-6">
                    {amountToAdd && `Cost: ₹${parseInt(amountToAdd, 10) || 0}`}
                </div>
                
                <div className="flex justify-end gap-4">
                    <button
                        onClick={() => setIsAddCoinsModalOpen(false)}
                        className="border border-gray-400 text-[#001233] dark:bg-[#001845] dark:text-[#EFEFDE] dark:border-gray-600 font-bold py-2 px-4 rounded-lg hover:bg-gray-100 dark:hover:bg-[#001845]/80 transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleAddCoins}
                        disabled={!amountToAdd || parseInt(amountToAdd, 10) <= 0}
                        className="bg-[#2A67C9] text-white font-bold py-2 px-4 rounded-lg hover:bg-[#255ab5] transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                    >
                        Purchase
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default WalletPage;