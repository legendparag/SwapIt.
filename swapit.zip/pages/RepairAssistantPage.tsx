import React, { useState } from 'react';
import { getRepairGuidanceFromAI, findNearbyRepairShops } from '../services/geminiService';
import type { RepairAnalysisResult, RepairShop } from '../types';
import { UploadIcon, DollarSignIcon, UserCheckIcon, WrenchIcon, AlertTriangleIcon, MapPinIcon } from '../components/Icons';

// Helper function to convert file to base64
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]); // remove the data URI prefix
        reader.onerror = error => reject(error);
    });
};

const InfoCard: React.FC<{ icon: React.ReactNode; label: string; children: React.ReactNode; }> = ({ icon, label, children }) => (
    <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[#2A67C9]/10 dark:bg-[#2A67C9]/20 flex items-center justify-center">
            {icon}
        </div>
        <div>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</p>
            <div className="text-[#001233] dark:text-[#EFEFDE] font-semibold text-base">{children}</div>
        </div>
    </div>
);

const RepairAssistantPage: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [analysisResult, setAnalysisResult] = useState<RepairAnalysisResult | null>(null);
    const [shops, setShops] = useState<RepairShop[]>([]);
    const [isFindingShops, setIsFindingShops] = useState(false);
    const [shopsError, setShopsError] = useState<string | null>(null);

    const handleFile = (file: File) => {
        if (file && file.type.startsWith('image/')) {
            setImageFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result as string);
            };
            reader.readAsDataURL(file);
            setAnalysisResult(null);
            setError(null);
        }
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); setIsDragging(true); };
    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => { e.preventDefault(); setIsDragging(false); };
    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            handleFile(e.dataTransfer.files[0]);
        }
    };
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            handleFile(e.target.files[0]);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim() || !imageFile || isLoading) return;

        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);
        setShops([]);
        setShopsError(null);

        try {
            const imageBase64 = await fileToBase64(imageFile);
            const result = await getRepairGuidanceFromAI(prompt, imageBase64, imageFile.type);
            setAnalysisResult(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleFindShops = () => {
        if (!analysisResult) return;

        setIsFindingShops(true);
        setShopsError(null);
        setShops([]);

        navigator.geolocation.getCurrentPosition(
            async (position) => {
                try {
                    const { latitude, longitude } = position.coords;
                    const foundShops = await findNearbyRepairShops(analysisResult.detectedIssue, latitude, longitude);
                    if (foundShops.length === 0) {
                        setShopsError("No repair shops found nearby based on the search.");
                    } else {
                        setShops(foundShops);
                    }
                } catch (err) {
                    setShopsError(err instanceof Error ? err.message : "Failed to find shops.");
                } finally {
                    setIsFindingShops(false);
                }
            },
            (error) => {
                console.error("Geolocation error:", error);
                setShopsError("Could not get your location. Please enable location services in your browser.");
                setIsFindingShops(false);
            }
        );
    };

    const isSubmitDisabled = !prompt.trim() || !imageFile || isLoading;

    return (
        <div className="animate-fadeIn">
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-[#001233] dark:text-[#EFEFDE]">Repair Assistant</h1>
                <p className="text-[#001233] dark:text-[#EFEFDE] mt-1">Describe the problem, upload a photo, and get AI-powered repair guidance.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700 space-y-6">
                    <form onSubmit={handleSubmit} className="flex flex-col h-full">
                        <label htmlFor="file-upload" className="cursor-pointer">
                            <div
                                onDragOver={handleDragOver}
                                onDragLeave={handleDragLeave}
                                onDrop={handleDrop}
                                className={`relative w-full h-52 border-2 border-dashed rounded-lg flex flex-col items-center justify-center transition-colors duration-300 ${isDragging ? 'border-[#2A67C9] bg-[#2A67C9]/10' : 'border-gray-300 dark:border-gray-600 hover:border-[#2A67C9]'}`}
                            >
                                <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*" />
                                {imagePreview ? (
                                    <img src={imagePreview} alt="Item Preview" className="absolute inset-0 w-full h-full object-cover rounded-lg" />
                                ) : (
                                    <div className="text-center text-[#001233] dark:text-[#EFEFDE]">
                                        <UploadIcon className="mx-auto h-10 w-10" />
                                        <p className="mt-2 font-semibold">Upload a photo</p>
                                        <p className="text-sm">Drag & drop or click</p>
                                    </div>
                                )}
                            </div>
                        </label>
                        
                        <div className="mt-4 flex-grow">
                            <label htmlFor="prompt" className="sr-only">Problem Description</label>
                            <textarea
                                id="prompt"
                                value={prompt}
                                onChange={e => setPrompt(e.target.value)}
                                placeholder="Describe the problem... e.g., 'My coffee machine is leaking from the bottom and making a strange noise.'"
                                className="w-full h-32 bg-gray-50 dark:bg-[#001845] text-[#001233] dark:text-[#EFEFDE] rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-[#2A67C9] border border-gray-200 dark:border-gray-600 resize-none"
                            />
                        </div>

                        <div className="mt-4">
                            <button type="submit" disabled={isSubmitDisabled} className="w-full bg-[#2A67C9] text-white font-bold py-3 px-4 rounded-lg hover:bg-[#255ab5] transition-colors flex items-center justify-center gap-2 disabled:bg-[#2A67C9]/50 disabled:cursor-not-allowed">
                                <WrenchIcon className="w-5 h-5" />
                                Get Repair Advice
                            </button>
                        </div>
                    </form>
                </div>
                
                <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700 flex flex-col">
                    <h2 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-4 flex-shrink-0">AI Analysis</h2>
                    <div className="flex-grow">
                        {isLoading && (
                            <div className="h-full flex flex-col items-center justify-center text-center p-4">
                                <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-[#2A67C9]"></div>
                                <p className="mt-4 text-[#001233] dark:text-[#EFEFDE]">Analyzing your item...</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">This may take a moment.</p>
                            </div>
                        )}
                        {error && (
                            <div className="h-full flex flex-col items-center justify-center text-center p-4 text-red-500 dark:text-red-400">
                                <AlertTriangleIcon className="w-12 h-12 mb-4"/>
                                <p className="font-semibold">Analysis Failed</p>
                                <p className="text-sm">{error}</p>
                            </div>
                        )}
                        {analysisResult && (
                             <div className="animate-fadeIn space-y-6">
                                <InfoCard icon={<AlertTriangleIcon className="w-5 h-5 text-[#EE9B00]" />} label="Detected Issue">
                                    <p className="text-red-600 dark:text-red-400 font-bold">{analysisResult.detectedIssue}</p>
                                </InfoCard>
                                <InfoCard icon={<WrenchIcon className="w-5 h-5 text-[#2A67C9]" />} label="Repair Summary">
                                    <p className="font-normal text-sm">{analysisResult.repairSummary}</p>
                                </InfoCard>
                                <InfoCard icon={<DollarSignIcon className="w-5 h-5 text-[#2A67C9]" />} label="Estimated Cost">
                                    {analysisResult.estimatedCost}
                                </InfoCard>
                                <InfoCard icon={<UserCheckIcon className="w-5 h-5 text-[#2A67C9]" />} label="DIY Friendly?">
                                    <span className={analysisResult.isDIYFriendly ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                                        {analysisResult.isDIYFriendly ? "Yes" : "No, professional recommended"}
                                    </span>
                                </InfoCard>
                                <InfoCard icon={<WrenchIcon className="w-5 h-5 text-[#2A67C9]" />} label="Required Parts & Tools">
                                    <ul className="list-disc list-inside space-y-1 mt-1 font-normal text-sm">
                                       {analysisResult.requiredParts.map(part => <li key={part}>{part}</li>)}
                                    </ul>
                                </InfoCard>

                                <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                                    <button
                                        onClick={handleFindShops}
                                        disabled={isFindingShops || !analysisResult}
                                        className="w-full bg-[#001233] text-white dark:text-[#EFEFDE] font-bold py-3 px-4 rounded-lg hover:bg-black/80 dark:hover:bg-[#001845] transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        {isFindingShops ? (
                                            <>
                                                <div className="w-5 h-5 border-2 border-dashed rounded-full animate-spin border-white"></div>
                                                Searching...
                                            </>
                                        ) : (
                                            <>
                                                <MapPinIcon className="w-5 h-5" />
                                                Find Nearby Repair Shops
                                            </>
                                        )}
                                    </button>
                                    <div className="mt-4 space-y-3">
                                        {shopsError && (
                                            <div className="text-center text-sm text-red-500 dark:text-red-400 p-3 bg-red-50 dark:bg-red-900/30 rounded-lg">
                                                <p>{shopsError}</p>
                                            </div>
                                        )}
                                        {shops.length > 0 && (
                                            <div className="animate-fadeIn">
                                                <h4 className="text-sm font-bold text-center text-[#001233] dark:text-[#EFEFDE] mb-3">Nearby Shops Found:</h4>
                                                <ul className="space-y-2 max-h-48 overflow-y-auto pr-2">
                                                    {shops.map((shop, index) => (
                                                        <li key={index} className="bg-gray-50 dark:bg-[#001845] p-3 rounded-lg border border-gray-200 dark:border-gray-700 flex items-center justify-between gap-3">
                                                            <div>
                                                                <p className="font-semibold text-sm text-[#001233] dark:text-[#EFEFDE]">{shop.title}</p>
                                                                <span className="text-xs text-gray-500 dark:text-gray-400">{new URL(shop.uri).hostname}</span>
                                                            </div>
                                                            <a href={shop.uri} target="_blank" rel="noopener noreferrer" className="text-xs font-bold bg-[#2A67C9] text-white py-1 px-3 rounded-md hover:bg-[#255ab5] transition-colors flex-shrink-0">
                                                                Visit
                                                            </a>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        )}
                         {!isLoading && !error && !analysisResult && (
                            <div className="h-full flex flex-col items-center justify-center text-center text-gray-500 dark:text-gray-400 p-4">
                                <p>Your repair analysis will appear here once you submit a request.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RepairAssistantPage;