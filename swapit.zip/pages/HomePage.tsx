import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { UploadIcon, WrenchIcon, SwapsIcon, TagIcon, CoinIcon, MapPinIcon, HeartIcon } from '../components/Icons';
import { getMarketplaceItems } from '../services/api';
import type { Item } from '../types';

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ icon, title, children }) => (
    <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700 text-center transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-xl">
        <div className="mx-auto w-16 h-16 rounded-full bg-[#2A67C9]/10 dark:bg-[#2A67C9]/20 flex items-center justify-center mb-4">
            {icon}
        </div>
        <h3 className="text-lg font-bold text-[#001233] dark:text-[#EFEFDE] mb-2">{title}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-400">{children}</p>
    </div>
);

const StepCard: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ icon, title, children }) => (
    <div className="flex flex-col items-center text-center p-4 transform transition-transform duration-300 hover:scale-105">
        <div className="mb-4">{icon}</div>
        <h3 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-2">{title}</h3>
        <p className="text-gray-600 dark:text-gray-400">{children}</p>
    </div>
);

const TestimonialCard: React.FC<{ avatar: string; username: string; children: React.ReactNode }> = ({ avatar, username, children }) => (
    <div className="bg-white dark:bg-[#001233] p-6 rounded-lg border border-gray-200 dark:border-gray-700">
        <p className="text-gray-600 dark:text-gray-400 italic">"{children}"</p>
        <div className="flex items-center mt-4">
            <img src={avatar} alt={username} className="w-12 h-12 rounded-full object-cover mr-4" />
            <div>
                <p className="font-bold text-[#001233] dark:text-[#EFEFDE]">@{username}</p>
            </div>
        </div>
    </div>
);

const ItemCard: React.FC<{ item: Item }> = ({ item }) => (
    <div className="bg-white dark:bg-[#001233] rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 group transform transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg flex flex-col">
        <div className="relative overflow-hidden">
            <img src={item.imageUrl} alt={item.name} className="w-full h-48 object-cover transform transition-transform duration-500 group-hover:scale-110" />
        </div>
        <div className="p-4 flex flex-col flex-grow">
            <h3 className="font-bold text-lg text-[#001233] dark:text-[#EFEFDE] truncate">{item.name}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">{item.condition}</p>
            <div className="flex justify-between items-center mt-auto">
                <div className="flex items-center gap-1 text-lg font-bold text-[#EE9B00] dark:text-[#E9D8A6]">
                    <CoinIcon className="w-5 h-5" />
                    <span>{item.value.toLocaleString()}</span>
                </div>
                <Link to="/items" className="text-sm font-semibold text-[#2A67C9] hover:underline dark:text-[#E9D8A6]">
                    View More
                </Link>
            </div>
        </div>
    </div>
);


const HomePage: React.FC = () => {
    const [popularItems, setPopularItems] = useState<Item[]>([]);

    useEffect(() => {
        const fetchItems = async () => {
            const allItems = await getMarketplaceItems();
            // Get a shuffled slice of items for variety
            const shuffled = allItems.sort(() => 0.5 - Math.random());
            setPopularItems(shuffled.slice(0, 4));
        };
        fetchItems();
    }, []);

    return (
        <div className="animate-fadeIn space-y-20 lg:space-y-32">
            {/* Hero Section */}
            <section className="relative text-center py-20 lg:py-32 rounded-lg overflow-hidden bg-gradient-to-br from-[#001233] to-[#2A67C9]">
                <div className="absolute inset-0 bg-cover bg-center opacity-10" style={{backgroundImage: "url('https://www.transparenttextures.com/patterns/cubes.png')"}}></div>
                <div className="relative z-10">
                    <h1 className="text-4xl md:text-6xl font-extrabold text-white dark:text-[#EFEFDE] leading-tight">
                        Swap Smarter. Earn Coins. Save More.
                    </h1>
                    <p className="mt-4 text-lg md:text-xl text-gray-300 dark:text-gray-400 max-w-3xl mx-auto">
                        Exchange products easily using AI-powered price detection and repair insights.
                    </p>
                    <div className="mt-8 flex justify-center gap-4 flex-wrap">
                        <Link
                            to="/items"
                            className="bg-[#2A67C9] text-white font-bold py-3 px-8 rounded-lg hover:bg-[#255ab5] transition-transform transform hover:scale-105"
                        >
                            Start Swapping
                        </Link>
                        <Link
                            to="/items/new"
                            className="bg-white dark:bg-[#EFEFDE] text-[#001233] font-bold py-3 px-8 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-300 transition-transform transform hover:scale-105"
                        >
                            Upload an Item
                        </Link>
                    </div>
                </div>
            </section>

            {/* How It Works Section */}
            <section>
                <h2 className="text-3xl font-bold text-center text-[#001233] dark:text-[#EFEFDE] mb-12">How SwapIt Works</h2>
                <div className="grid md:grid-cols-3 gap-8">
                    <StepCard icon={<UploadIcon className="w-20 h-20 text-[#2A67C9]" />} title="1. Upload Your Product">
                        Snap a photo of your item and provide a brief description. It's quick and easy to list what you want to swap.
                    </StepCard>
                    <StepCard icon={<WrenchIcon className="w-20 h-20 text-[#2A67C9]" />} title="2. Get AI Insights">
                        Our AI analyzes your item's condition, suggests a fair coin value, and even identifies potential repair needs.
                    </StepCard>
                    <StepCard icon={<SwapsIcon className="w-20 h-20 text-[#2A67C9]" />} title="3. Swap for Coins">
                        Use your item's value to trade with others. Our coin system makes every swap fair and simple.
                    </StepCard>
                </div>
            </section>

            {/* AI Feature Highlights */}
            <section>
                <h2 className="text-3xl font-bold text-center text-[#001233] dark:text-[#EFEFDE] mb-12">Why Choose SwapIt?</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    <FeatureCard icon={<TagIcon className="w-8 h-8 text-[#2A67C9]" />} title="AI Product Valuation">
                        Get instant, fair market value estimates for your items in SwapCoins, ensuring you always get a great deal.
                    </FeatureCard>
                    <FeatureCard icon={<HeartIcon className="w-8 h-8 text-[#2A67C9]" />} title="Smart Swap Matching">
                        Our algorithm suggests the best potential swaps for you based on your items and interests.
                    </FeatureCard>
                    <FeatureCard icon={<CoinIcon className="w-8 h-8 text-[#2A67C9]" />} title="Digital Coin System">
                        Our flexible coin system balances trades, allowing you to swap items of different values seamlessly.
                    </FeatureCard>
                    <FeatureCard icon={<MapPinIcon className="w-8 h-8 text-[#2A67C9]" />} title="Local Swaps">
                        Find and trade with users in your area to save on shipping and build your local community.
                    </FeatureCard>
                </div>
            </section>

            {/* Featured Items Section */}
            <section>
                <h2 className="text-3xl font-bold text-center text-[#001233] dark:text-[#EFEFDE] mb-12">Popular Items</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    {popularItems.map(item => (
                        <ItemCard key={item.id} item={item} />
                    ))}
                </div>
            </section>
            
            {/* Testimonials Section */}
            <section>
                <h2 className="text-3xl font-bold text-center text-[#001233] dark:text-[#EFEFDE] mb-12">What Our Users Say</h2>
                <div className="grid md:grid-cols-3 gap-8">
                    <TestimonialCard avatar="https://i.pravatar.cc/150?u=user1" username="retro_gamer">
                        SwapIt's AI valuation was spot on for my old console. Made a fair trade for a camera I've wanted for ages!
                    </TestimonialCard>
                    <TestimonialCard avatar="https://i.pravatar.cc/150?u=user2" username="crafty_carla">
                        I love the coin system. It makes swapping so much easier when items aren't an exact match in value.
                    </TestimonialCard>
                    <TestimonialCard avatar="https://i.pravatar.cc/150?u=user3" username="fashionista_fay">
                        Found someone local to swap a designer jacket with. The whole process was smooth and secure. Highly recommend!
                    </TestimonialCard>
                </div>
            </section>
        </div>
    );
};

export default HomePage;
