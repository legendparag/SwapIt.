import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getMockConversations, getMockMessages, sendMockMessage } from '../services/api';
import { useAuth } from '../contexts/AuthContext';
import type { ChatConversation, ChatMessage } from '../types';
import { MessagesIcon, ArrowLeftIcon, PaperAirplaneIcon } from '../components/Icons';

const MessagesPage: React.FC = () => {
    const { conversationId } = useParams<{ conversationId?: string }>();
    const navigate = useNavigate();
    const messagesEndRef = useRef<null | HTMLDivElement>(null);

    const [conversations, setConversations] = useState<ChatConversation[]>([]);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const { currentUser } = useAuth();
    const [newMessage, setNewMessage] = useState('');
    const [isLoading, setIsLoading] = useState({ convos: true, messages: false });

    useEffect(() => {
        const fetchData = async () => {
            if (!currentUser) {
                setIsLoading(prev => ({ ...prev, convos: false }));
                return;
            }
            setIsLoading(prev => ({ ...prev, convos: true }));
            try {
                const convosData = await getMockConversations(currentUser.username);
                setConversations(convosData.sort((a,b) => new Date(b.lastMessage.timestamp).getTime() - new Date(a.lastMessage.timestamp).getTime()));
            } catch (error) {
                console.error("Failed to fetch conversations or user profile", error);
            } finally {
                setIsLoading(prev => ({ ...prev, convos: false }));
            }
        };
        fetchData();
    }, [currentUser]);

    useEffect(() => {
        const fetchMessages = async () => {
            if (conversationId) {
                setIsLoading(prev => ({ ...prev, messages: true }));
                try {
                    const messagesData = await getMockMessages(conversationId);
                    setMessages(messagesData);
                } catch (error) {
                    console.error(`Failed to fetch messages for convo ${conversationId}`, error);
                    setMessages([]);
                } finally {
                    setIsLoading(prev => ({ ...prev, messages: false }));
                }
            } else {
                setMessages([]);
            }
        };
        fetchMessages();

        // Polling for new messages
        const intervalId = setInterval(fetchMessages, 3000);

        return () => clearInterval(intervalId); // Cleanup on component unmount or conversation change
    }, [conversationId]);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || !conversationId || !currentUser) return;

        const optimisticMessage: ChatMessage = {
            id: `msg-${Date.now()}`,
            conversationId,
            senderUsername: currentUser.username,
            text: newMessage,
            timestamp: new Date().toISOString()
        };
        
        // Optimistic UI update for instant feedback
        setMessages(prev => [...prev, optimisticMessage]);
        setNewMessage('');
        
        try {
            await sendMockMessage(conversationId, currentUser.username, newMessage);
            // Optionally, re-fetch messages to ensure sync, though polling will handle this
        } catch (error) {
            console.error("Failed to send message", error);
            // Revert optimistic update on error if needed
            setMessages(prev => prev.filter(m => m.id !== optimisticMessage.id));
        }
    };
    
    const activeConversation = conversations.find(c => c.id === conversationId);

    return (
        <div className="flex h-[calc(100vh-4rem)] bg-white dark:bg-[#001233]/80 rounded-lg border border-gray-200 dark:border-gray-700 animate-fadeIn overflow-hidden">
            {/* Conversation List */}
            <aside className={`w-full md:w-1/3 lg:w-1/4 border-r border-gray-200 dark:border-gray-700 flex flex-col ${conversationId && 'hidden md:flex'}`}>
                <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                    <h1 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE]">Messages</h1>
                </div>
                <div className="flex-1 overflow-y-auto">
                    {isLoading.convos ? (
                        <div className="p-4 text-center text-gray-500">Loading conversations...</div>
                    ) : (
                        <ul>
                            {conversations.map(convo => (
                                <li key={convo.id} onClick={() => navigate(`/messages/${convo.id}`)}
                                    className={`p-4 cursor-pointer border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-[#001845]/50 transition-colors ${convo.id === conversationId ? 'bg-[#2A67C9]/10 dark:bg-[#2A67C9]/20' : ''}`}
                                >
                                    <div className="flex items-center gap-4">
                                        <div className="relative flex-shrink-0">
                                            <img src={convo.otherUser.avatarUrl} alt={convo.otherUser.username} className="w-12 h-12 rounded-full object-cover" />
                                            <img src={convo.item.imageUrl} alt={convo.item.name} className="w-6 h-6 rounded-full object-cover absolute -bottom-1 -right-1 border-2 border-white dark:border-[#001233]" />
                                        </div>
                                        <div className="flex-1 overflow-hidden">
                                            <div className="flex justify-between items-start">
                                                <p className="font-bold text-sm text-[#001233] dark:text-[#EFEFDE] truncate">@{convo.otherUser.username}</p>
                                                {convo.unreadCount > 0 && <span className="text-xs bg-[#2A67C9] text-white font-bold rounded-full w-5 h-5 flex items-center justify-center">{convo.unreadCount}</span>}
                                            </div>
                                            <p className="text-xs text-gray-500 dark:text-gray-400 font-medium truncate">{convo.item.name}</p>
                                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 truncate">
                                                {convo.lastMessage.senderUsername === currentUser?.username && 'You: '}{convo.lastMessage.text}
                                            </p>
                                        </div>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </aside>
            
            {/* Message View */}
            <main className={`flex-1 flex flex-col ${!conversationId && 'hidden md:flex'}`}>
                {activeConversation && currentUser ? (
                    <div className="flex flex-col h-full">
                        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-4">
                            <button onClick={() => navigate('/messages')} className="md:hidden p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                                <ArrowLeftIcon className="w-5 h-5"/>
                            </button>
                            <img src={activeConversation.otherUser.avatarUrl} alt={activeConversation.otherUser.username} className="w-10 h-10 rounded-full object-cover"/>
                            <div>
                                <h2 className="font-bold text-[#001233] dark:text-[#EFEFDE]">@{activeConversation.otherUser.username}</h2>
                                <p className="text-xs text-gray-500 dark:text-gray-400">re: {activeConversation.item.name}</p>
                            </div>
                        </div>
                        <div className="flex-1 p-6 overflow-y-auto space-y-4">
                            {isLoading.messages && messages.length === 0 ? (
                                <div className="text-center text-gray-500">Loading messages...</div>
                            ) : (
                                messages.map(msg => (
                                    <div key={msg.id} className={`flex gap-3 ${msg.senderUsername === currentUser.username ? 'justify-end' : 'justify-start'}`}>
                                        {msg.senderUsername !== currentUser.username && (
                                            <img src={activeConversation.otherUser.avatarUrl} alt={activeConversation.otherUser.username} className="w-8 h-8 rounded-full object-cover flex-shrink-0"/>
                                        )}
                                        <div className={`max-w-xs lg:max-w-md p-3 rounded-lg ${msg.senderUsername === currentUser.username ? 'bg-[#2A67C9] text-white rounded-br-none' : 'bg-gray-200 dark:bg-[#001845] text-[#001233] dark:text-[#EFEFDE] rounded-bl-none'}`}>
                                            <p className="text-sm">{msg.text}</p>
                                        </div>
                                    </div>
                                ))
                            )}
                            <div ref={messagesEndRef} />
                        </div>
                        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                            <form onSubmit={handleSendMessage} className="flex items-center gap-4">
                                <input type="text" value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type a message..." className="flex-1 bg-gray-100 dark:bg-[#001845] rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-[#2A67C9] border border-transparent transition text-[#001233] dark:text-[#EFEFDE]"/>
                                <button type="submit" disabled={!newMessage.trim()} className="bg-[#2A67C9] text-white rounded-full p-3 hover:bg-[#255ab5] transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed">
                                    <PaperAirplaneIcon className="w-5 h-5"/>
                                </button>
                            </form>
                        </div>
                    </div>
                ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-center text-gray-500 dark:text-gray-400 p-4">
                         <MessagesIcon className="w-16 h-16 mx-auto text-gray-300 dark:text-gray-600 mb-4" />
                        <h2 className="text-lg font-semibold">Select a conversation</h2>
                        <p>Choose a conversation from the list to start chatting.</p>
                    </div>
                )}
            </main>
        </div>
    );
};

export default MessagesPage;