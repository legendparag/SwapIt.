import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('alex_swapper');
  const [password, setPassword] = useState('password123');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await login(username, password);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-[#EFEFDE] dark:bg-[#001845] p-4">
      <div className="w-full max-w-4xl grid md:grid-cols-2 shadow-2xl rounded-lg overflow-hidden">
        <div className="hidden md:flex flex-col items-center justify-center bg-gradient-to-br from-[#001233] to-[#001845] p-12 text-white text-center">
            <h1 className="text-5xl font-bold tracking-wider">
                Swap<span className="text-[#2A67C9]">It</span>
            </h1>
            <p className="mt-4 text-lg opacity-80">Trade, Repair, and Discover. Your sustainable marketplace awaits.</p>
        </div>
        <div className="bg-white dark:bg-[#001233]/80 p-8 md:p-12">
            <h2 className="text-3xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-6 text-center">Log In</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
                {error && <p className="bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300 p-3 rounded-md text-sm">{error}</p>}
                <div>
                    <label className="block text-sm font-medium text-gray-600 dark:text-gray-400 mb-1" htmlFor="username">Username</label>
                    <input
                        id="username"
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                        className="w-full bg-gray-100 dark:bg-[#001845] text-[#001233] dark:text-white rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#2A67C9] border border-gray-300 dark:border-gray-600"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-600 dark:text-gray-400 mb-1" htmlFor="password">Password</label>
                    <input
                        id="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="w-full bg-gray-100 dark:bg-[#001845] text-[#001233] dark:text-white rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#2A67C9] border border-gray-300 dark:border-gray-600"
                    />
                </div>
                <button
                    type="submit"
                    className="w-full bg-[#2A67C9] text-white font-bold py-3 px-4 rounded-lg hover:bg-[#255ab5] transition-colors disabled:bg-gray-400"
                >
                    Log In
                </button>
            </form>
            <div className="mt-6 text-center">
                <p className="text-sm text-[#001233] dark:text-[#EFEFDE]">
                    Don't have an account?{' '}
                    <Link to="/signup" className="font-semibold text-[#2A67C9] hover:underline">
                        Sign Up
                    </Link>
                </p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;