import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Swap, CoinTransaction } from '../types';
import { getMockSwaps, getMockCoinTransactions, respondToSwap } from '../services/api';
import { useAuth } from '../contexts/AuthContext';
import { StarIcon, CoinIcon, ArrowLongRightIcon, AlertTriangleIcon, PlusIcon } from '../components/Icons';

const getStatusClasses = (status: Swap['status']) => {
  switch (status) {
    case 'Pending': return 'bg-yellow-100 text-yellow-800 dark:bg-[#E9D8A6]/20 dark:text-[#E9D8A6]';
    case 'Accepted': return 'bg-sky-100 text-sky-800 dark:bg-[#2A67C9]/20 dark:text-[#EFEFDE]';
    case 'Completed': return 'bg-emerald-100 text-emerald-800 dark:bg-green-500/20 dark:text-green-300';
    case 'Rejected': return 'bg-red-100 text-red-800 dark:bg-red-500/20 dark:text-red-300';
    default: return 'bg-gray-100 text-gray-800 dark:bg-gray-500/10 dark:text-gray-400';
  }
};

const FeedbackModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (rating: number, comment: string) => void;
  swap: Swap | null;
}> = ({ isOpen, onClose, onSubmit, swap }) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');

  useEffect(() => {
    if (!isOpen) {
      setRating(0);
      setHoverRating(0);
      setComment('');
    }
  }, [isOpen]);

  if (!isOpen || !swap) return null;

  const handleSubmit = () => {
    onSubmit(rating, comment);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 animate-fadeIn">
      <div className="bg-white dark:bg-[#001233] rounded-lg shadow-xl w-full max-w-md p-6 border border-gray-200 dark:border-gray-700">
        <h2 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-2">Leave Feedback</h2>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
          How was your swap for{' '}
          <span className="font-semibold">{swap.otherUserItem.name}</span>?
        </p>

        <div className="flex justify-center space-x-2 my-6">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
              className="focus:outline-none"
              aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
            >
              <StarIcon
                className={`w-10 h-10 transition-colors duration-200 ${
                  star <= (hoverRating || rating) ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'
                }`}
              />
            </button>
          ))}
        </div>

        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Add a comment... (optional)"
          className="w-full h-24 bg-gray-100 dark:bg-[#001845] text-[#001233] dark:text-[#EFEFDE] rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-[#2A67C9] border border-transparent transition-colors"
        />

        <div className="mt-6 flex justify-end gap-4">
          <button
            onClick={onClose}
            className="border border-gray-400 text-[#001233] dark:bg-[#001845] dark:text-[#EFEFDE] dark:border-gray-600 font-bold py-2 px-4 rounded-lg hover:bg-gray-100 dark:hover:bg-[#001845]/80 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={rating === 0}
            className="bg-[#2A67C9] text-white font-bold py-2 px-4 rounded-lg hover:bg-[#255ab5] transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};

const AddCoinsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onAddCoins: (amount: number) => void;
}> = ({ isOpen, onClose, onAddCoins }) => {
    const [amountToAdd, setAmountToAdd] = useState('');
    
    if (!isOpen) return null;

    const handlePurchase = () => {
        const amount = parseInt(amountToAdd, 10);
        if(!isNaN(amount) && amount > 0) {
            onAddCoins(amount);
            setAmountToAdd('');
        }
    }

    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 animate-fadeIn">
            <div className="bg-white dark:bg-[#001233] rounded-lg shadow-xl w-full max-w-md p-6 border border-gray-200 dark:border-gray-700">
                <h2 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-2">Purchase SwapCoins</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Coins are used to balance swaps. ₹1 = 1 Coin.</p>
                
                <div className="relative my-4">
                    <input 
                        type="number"
                        value={amountToAdd}
                        onChange={(e) => setAmountToAdd(e.target.value)}
                        placeholder="Enter amount"
                        className="w-full bg-gray-100 dark:bg-[#001845] text-[#001233] dark:text-[#EFEFDE] rounded-md py-3 pl-10 pr-4 text-lg focus:outline-none focus:ring-2 focus:ring-[#2A67C9]"
                    />
                    <CoinIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 text-[#EE9B00]" />
                </div>

                <div className="flex justify-center gap-2 mb-4">
                    {[100, 500, 1000].map(amount => (
                        <button key={amount} onClick={() => setAmountToAdd(String(amount))} className="border border-gray-300 dark:border-gray-600 text-[#001233] dark:text-[#EFEFDE] font-semibold py-1 px-4 rounded-full hover:bg-gray-100 dark:hover:bg-[#001845] transition-colors">
                            {amount}
                        </button>
                    ))}
                </div>

                <div className="text-center text-sm text-gray-500 dark:text-gray-400 mb-6">
                    {amountToAdd && `Cost: ₹${parseInt(amountToAdd, 10) || 0}`}
                </div>
                
                <div className="flex justify-end gap-4">
                    <button
                        onClick={onClose}
                        className="border border-gray-400 text-[#001233] dark:bg-[#001845] dark:text-[#EFEFDE] dark:border-gray-600 font-bold py-2 px-4 rounded-lg hover:bg-gray-100 dark:hover:bg-[#001845]/80 transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handlePurchase}
                        disabled={!amountToAdd || parseInt(amountToAdd, 10) <= 0}
                        className="bg-[#2A67C9] text-white font-bold py-2 px-4 rounded-lg hover:bg-[#255ab5] transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                    >
                        Purchase
                    </button>
                </div>
            </div>
        </div>
    );
};

const SwapRow: React.FC<{
  swap: Swap;
  isIncoming: boolean;
  balance: number;
  onAccept: (swapId: string) => void;
  onReject: (swapId: string) => void;
  onLeaveFeedback: (swap: Swap) => void;
  onBuyCoins: () => void;
}> = ({ swap, isIncoming, balance, onAccept, onReject, onLeaveFeedback, onBuyCoins }) => {
    const { currentUser } = useAuth();
    
    // For incoming requests, userItem is from the other person, otherUserItem is mine
    // For outgoing requests, userItem is mine, otherUserItem is the other person's
    const myItem = isIncoming ? swap.otherUserItem : swap.userItem;
    const theirItem = isIncoming ? swap.userItem : swap.otherUserItem;

    // coinDifference is from the proposer's perspective.
    // If incoming, I am the receiver. If proposer pays (negative diff), I receive coins.
    const coinDifferenceForMe = isIncoming ? (swap.coinDifference ? -swap.coinDifference : 0) : swap.coinDifference ?? 0;
    
    const coinsToPay = coinDifferenceForMe < 0 ? Math.abs(coinDifferenceForMe) : 0;
    const coinShortage = coinsToPay > 0 && coinsToPay > balance;

    return (
        <tr className="hover:bg-gray-50 dark:hover:bg-[#001233]/50 transition-colors">
            <td className="px-6 py-4 whitespace-nowrap text-sm">
                <div className="flex items-center gap-2">
                    <div className="font-medium text-[#001233] dark:text-[#EFEFDE] text-right">
                        <p className="text-gray-500 dark:text-gray-400 text-xs">You Give</p>
                        <p>{myItem.name}</p>
                        <div className="flex items-center justify-end gap-1 text-xs text-[#EE9B00] dark:text-[#E9D8A6]">
                            <span>{myItem.value.toLocaleString()}</span><CoinIcon className="w-3 h-3" />
                        </div>
                    </div>
                    <ArrowLongRightIcon className="w-8 h-8 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                    <div className="font-medium text-[#001233] dark:text-[#EFEFDE] text-left">
                        <p className="text-gray-500 dark:text-gray-400 text-xs">You Get</p>
                        <p>{theirItem.name}</p>
                        <div className="flex items-center justify-start gap-1 text-xs text-[#EE9B00] dark:text-[#E9D8A6]">
                            <span>{theirItem.value.toLocaleString()}</span><CoinIcon className="w-3 h-3" />
                        </div>
                    </div>
                    {coinDifferenceForMe !== 0 && (
                        <div className={`flex items-center font-bold text-xs ml-2 ${coinDifferenceForMe > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                            <span>{coinDifferenceForMe > 0 ? '+' : ''}{coinDifferenceForMe.toLocaleString()}</span>
                            <CoinIcon className="w-3 h-3 ml-1" />
                        </div>
                    )}
                    {isIncoming && swap.status === 'Pending' && coinShortage && (
                         <div className="ml-4 p-2 bg-red-100 dark:bg-red-900/50 rounded-lg flex items-center gap-2">
                             <AlertTriangleIcon className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0" />
                             <div>
                                 <p className="text-xs font-bold text-red-700 dark:text-red-300">Insufficient coins!</p>
                                 <button onClick={onBuyCoins} className="text-xs text-sky-600 dark:text-sky-400 hover:underline font-semibold">Buy more</button>
                             </div>
                         </div>
                     )}
                </div>
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-sm">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClasses(swap.status)}`}>
                    {swap.status}
                </span>
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">{swap.date}</td>
            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                {isIncoming && swap.status === 'Pending' && (
                    <div className="flex items-center gap-2">
                        <button onClick={() => onAccept(swap.id)} disabled={coinShortage} className="bg-green-600 text-white font-semibold text-xs py-1 px-3 rounded-md hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed">Accept</button>
                        <button onClick={() => onReject(swap.id)} className="bg-red-600 text-white font-semibold text-xs py-1 px-3 rounded-md hover:bg-red-700 transition-colors">Reject</button>
                    </div>
                )}
                {swap.status === 'Completed' && (
                    swap.feedbackGiven ? (
                        <span className="text-gray-400 dark:text-gray-500 text-xs">Feedback Sent</span>
                    ) : (
                        <button onClick={() => onLeaveFeedback(swap)} className="text-[#2A67C9] hover:text-[#255ab5] dark:text-[#E9D8A6] dark:hover:text-white font-semibold transition-colors text-xs">
                            Leave Feedback
                        </button>
                    )
                )}
            </td>
        </tr>
    );
};

const SwapTable: React.FC<{
    title: string;
    swaps: Swap[];
    isIncoming: boolean;
    balance: number;
    onAccept: (swapId: string) => void;
    onReject: (swapId: string) => void;
    onLeaveFeedback: (swap: Swap) => void;
    onBuyCoins: () => void;
}> = ({ title, swaps, isIncoming, ...props }) => {
    if (swaps.length === 0) return null;
    return (
        <div className="mb-12">
            <h2 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-4">{title} ({swaps.length})</h2>
            <div className="bg-white dark:bg-[#001233] rounded-lg border border-gray-200 dark:border-gray-700 overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead className="bg-gray-50 dark:bg-[#001233]">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Swap Details</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Date</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-[#001845] divide-y divide-gray-200 dark:divide-gray-700">
                        {swaps.map((swap) => <SwapRow key={swap.id} swap={swap} isIncoming={isIncoming} {...props} />)}
                    </tbody>
                </table>
            </div>
        </div>
    );
};


const SwapsPage: React.FC = () => {
  const [swaps, setSwaps] = useState<Swap[]>([]);
  const [transactions, setTransactions] = useState<CoinTransaction[]>([]);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
  const [isAddCoinsModalOpen, setIsAddCoinsModalOpen] = useState(false);
  const [selectedSwap, setSelectedSwap] = useState<Swap | null>(null);
  const navigate = useNavigate();
  const { currentUser, refreshCurrentUser } = useAuth();

  const fetchSwapsAndBalance = async () => {
    if (!currentUser) return;
    const mockSwaps = await getMockSwaps(currentUser.username);
    setSwaps(mockSwaps);
    const mockTransactions = await getMockCoinTransactions(currentUser.username);
    setTransactions(mockTransactions);
  };

  useEffect(() => {
    fetchSwapsAndBalance();
  }, [currentUser]);

  const balance = useMemo(() => {
      return transactions.reduce((acc, tx) => acc + (tx.type === 'Credit' ? tx.amount : -Math.abs(tx.amount)), 0);
  }, [transactions]);

  const handleResponse = async (swapId: string, response: 'Accepted' | 'Rejected') => {
      try {
          await respondToSwap(swapId, response);
          await fetchSwapsAndBalance(); // Re-fetch all data
          await refreshCurrentUser(); // Refresh user profile in context
      } catch (error) {
          console.error(`Failed to ${response.toLowerCase()} swap:`, error);
          // You could show an error toast here
      }
  };

  const handleOpenFeedbackModal = (swap: Swap) => {
    setSelectedSwap(swap);
    setIsFeedbackModalOpen(true);
  };

  const handleCloseFeedbackModal = () => {
    setIsFeedbackModalOpen(false);
    setSelectedSwap(null);
  };

  const handleSubmitFeedback = (rating: number, comment: string) => {
    if (!selectedSwap) return;
    console.log(`Submitting feedback for swap ${selectedSwap.id}:`, { rating, comment });
    setSwaps((prevSwaps) =>
      prevSwaps.map((s) =>
        s.id === selectedSwap.id ? { ...s, feedbackGiven: true } : s
      )
    );
  };
  
  const handleAddCoins = (amount: number) => {
    navigate('/payment-gateway', { state: { amount } });
    setIsAddCoinsModalOpen(false);
  };

  const { incoming, outgoing } = useMemo(() => {
      if (!currentUser) return { incoming: [], outgoing: [] };
      const incoming: Swap[] = [];
      const outgoing: Swap[] = [];
      swaps.forEach(s => {
          if (s.proposerUsername !== currentUser.username) {
              incoming.push(s);
          } else {
              outgoing.push(s);
          }
      });
      return { incoming, outgoing };
  }, [swaps, currentUser]);

  return (
    <div className="animate-fadeIn">
      <h1 className="text-3xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-2">Your Swaps</h1>
      <p className="text-[#001233] dark:text-[#EFEFDE] mb-8">Track the status of all your swap requests and history.</p>

      <SwapTable
        title="Incoming Requests"
        swaps={incoming}
        isIncoming={true}
        balance={balance}
        onAccept={(id) => handleResponse(id, 'Accepted')}
        onReject={(id) => handleResponse(id, 'Rejected')}
        onLeaveFeedback={handleOpenFeedbackModal}
        onBuyCoins={() => setIsAddCoinsModalOpen(true)}
      />
      
      <SwapTable
        title="Outgoing Proposals"
        swaps={outgoing}
        isIncoming={false}
        balance={balance}
        onAccept={(id) => handleResponse(id, 'Accepted')}
        onReject={(id) => handleResponse(id, 'Rejected')}
        onLeaveFeedback={handleOpenFeedbackModal}
        onBuyCoins={() => setIsAddCoinsModalOpen(true)}
      />

      {swaps.length === 0 && (
          <div className="text-center text-gray-500 dark:text-gray-400 py-20">
              <p className="text-lg font-semibold">No swaps yet!</p>
              <p>Propose a swap from the Items page to get started.</p>
          </div>
      )}
      
      <FeedbackModal
        isOpen={isFeedbackModalOpen}
        onClose={handleCloseFeedbackModal}
        onSubmit={handleSubmitFeedback}
        swap={selectedSwap}
      />
      <AddCoinsModal
        isOpen={isAddCoinsModalOpen}
        onClose={() => setIsAddCoinsModalOpen(false)}
        onAddCoins={handleAddCoins}
      />
    </div>
  );
};

export default SwapsPage;