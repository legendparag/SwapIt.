import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const AnimatedCheckmark: React.FC = () => (
    <svg className="w-24 h-24" viewBox="0 0 52 52">
        <circle className="stroke-current text-green-100 dark:text-green-900" cx="26" cy="26" r="25" fill="none" strokeWidth="4" />
        <path 
            className="stroke-current text-green-500" 
            fill="none" 
            strokeWidth="5"
            strokeLinecap="round"
            strokeDasharray="48"
            strokeDashoffset="48"
            d="M14.1 27.2l7.1 7.2 16.7-16.8"
        >
            <animate attributeName="stroke-dashoffset" from="48" to="0" dur="0.5s" begin="0.2s" fill="freeze" />
        </path>
    </svg>
);


const PaymentSuccessPage: React.FC = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const { addCoins } = useAuth();
    const { amount } = location.state || { amount: 0 };

    useEffect(() => {
        if (amount > 0) {
            addCoins(amount).catch(err => {
                console.error("Failed to add coins", err);
                // Optionally handle error, e.g., show a message to the user
            });
        }

        const redirectTimer = setTimeout(() => {
            navigate('/wallet', { replace: true });
        }, 3000);

        return () => clearTimeout(redirectTimer);
    }, [amount, addCoins, navigate]);
    
    return (
        <div className="flex flex-col items-center justify-center h-full text-center p-4 animate-fadeIn">
            <AnimatedCheckmark />
            <h1 className="text-3xl font-bold text-green-600 dark:text-green-400 mt-6">Payment Successful!</h1>
            <p className="text-lg text-[#001233] dark:text-[#EFEFDE] mt-2">
                <span className="font-bold">{amount.toLocaleString()} SwapCoins</span> have been added to your wallet.
            </p>
            <p className="text-gray-500 dark:text-gray-400 mt-4">You will be redirected to your wallet shortly...</p>
        </div>
    );
};

export default PaymentSuccessPage;