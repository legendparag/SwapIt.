import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Item, CoinTransaction, UserProfile } from '../types';
import { getMarketplaceItems, getMockItemsForUser, getMockCoinTransactions, proposeSwap } from '../services/api';
import { useAuth } from '../contexts/AuthContext';
import { SearchIcon, CoinIcon, HeartIcon, SwapsIcon, AlertTriangleIcon, AdjustmentsHorizontalIcon, MapPinIcon, PlusIcon, UploadIcon, PencilIcon, TrashIcon } from '../components/Icons';

const ItemPreviewCard: React.FC<{
    item: Item;
    position: { top: number; left: number };
    onMouseEnter: () => void;
    onMouseLeave: () => void;
}> = ({ item, position, onMouseEnter, onMouseLeave }) => {
    return (
        <div
            style={position}
            className="fixed z-50 w-72 bg-white dark:bg-[#001233] rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 animate-fadeIn p-4 flex flex-col gap-3"
            onMouseEnter={onMouseEnter}
            onMouseLeave={onMouseLeave}
        >
            <img src={item.imageUrl} alt={item.name} className="w-full h-40 object-cover rounded-lg" />
            <div>
                <h3 className="text-lg font-bold text-[#001233] dark:text-[#EFEFDE] truncate">{item.name}</h3>
                <div className="flex items-center justify-between mt-1">
                    <div className="flex items-center gap-1 text-lg font-bold text-[#EE9B00] dark:text-[#E9D8A6]">
                        <CoinIcon className="w-5 h-5" />
                        <span>{item.value.toLocaleString()}</span>
                    </div>
                    <span className="text-xs font-semibold px-2 py-1 bg-gray-100 dark:bg-[#001845] rounded-full text-gray-600 dark:text-gray-400">
                        {item.condition}
                    </span>
                </div>
            </div>
            <p
                className="text-sm text-gray-600 dark:text-gray-400"
                style={{
                    display: '-webkit-box',
                    WebkitLineClamp: 3,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                }}
            >
                {item.description}
            </p>
        </div>
    );
};

const AddCoinsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onAddCoins: (amount: number) => void;
}> = ({ isOpen, onClose, onAddCoins }) => {
    const [amountToAdd, setAmountToAdd] = useState('');

    if (!isOpen) return null;

    const handlePurchase = () => {
        const amount = parseInt(amountToAdd, 10);
        if(!isNaN(amount) && amount > 0) {
            onAddCoins(amount);
            setAmountToAdd('');
        }
    }

    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 animate-fadeIn">
            <div className="bg-white dark:bg-[#001233] rounded-lg shadow-xl w-full max-w-md p-6 border border-gray-200 dark:border-gray-700">
                <h2 className="text-xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-2">Purchase SwapCoins</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Coins are used to balance swaps. ₹1 = 1 Coin.</p>
                
                <div className="relative my-4">
                    <input
                        type="number"
                        value={amountToAdd}
                        onChange={(e) => setAmountToAdd(e.target.value)}
                        placeholder="Enter amount"
                        className="w-full bg-gray-100 dark:bg-[#001845] text-[#001233] dark:text-[#EFEFDE] rounded-md py-3 pl-10 pr-4 text-lg focus:outline-none focus:ring-2 focus:ring-[#2A67C9]"
                    />
                    <CoinIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 text-[#EE9B00]" />
                </div>

                <div className="flex justify-center gap-2 mb-4">
                    {[100, 500, 1000].map(amount => (
                        <button key={amount} onClick={() => setAmountToAdd(String(amount))} className="border border-gray-300 dark:border-gray-600 text-[#001233] dark:text-[#EFEFDE] font-semibold py-1 px-4 rounded-full hover:bg-gray-100 dark:hover:bg-[#001845] transition-colors">
                            {amount}
                        </button>
                    ))}
                </div>

                <div className="text-center text-sm text-gray-500 dark:text-gray-400 mb-6">
                    {amountToAdd && `Cost: ₹${parseInt(amountToAdd, 10) || 0}`}
                </div>
                
                <div className="flex justify-end gap-4">
                    <button
                        onClick={onClose}
                        className="border border-gray-400 text-[#001233] dark:bg-[#001845] dark:text-[#EFEFDE] dark:border-gray-600 font-bold py-2 px-4 rounded-lg hover:bg-gray-100 dark:hover:bg-[#001845]/80 transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handlePurchase}
                        disabled={!amountToAdd || parseInt(amountToAdd, 10) <= 0}
                        className="bg-[#2A67C9] text-white font-bold py-2 px-4 rounded-lg hover:bg-[#255ab5] transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                    >
                        Purchase
                    </button>
                </div>
            </div>
        </div>
    );
};

const SwapModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  marketplaceItem: Item | null;
  userItems: Item[];
  balance: number;
  onBuyCoins: () => void;
  currentUser: UserProfile | null;
}> = ({ isOpen, onClose, marketplaceItem, userItems, balance, onBuyCoins, currentUser }) => {
    const [selectedUserItemId, setSelectedUserItemId] = useState<string>('');
    const [isProposing, setIsProposing] = useState(false);
    const [proposalError, setProposalError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        if (isOpen) {
            setSelectedUserItemId('');
            setIsProposing(false);
            setProposalError('');
        }
    }, [isOpen]);
    
    const handleProposeSwap = async () => {
        if (!marketplaceItem || !selectedUserItemId || !currentUser) return;
        
        setIsProposing(true);
        setProposalError('');
        try {
            await proposeSwap(selectedUserItemId, marketplaceItem.id, currentUser);
            onClose();
            navigate('/swaps'); // Navigate to swaps page to see the new proposal
        } catch (err) {
            setProposalError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsProposing(false);
        }
    };


    if (!isOpen || !marketplaceItem) return null;

    const selectedUserItem = userItems.find(item => item.id === selectedUserItemId);
    const coinDifference = selectedUserItem ? selectedUserItem.value - marketplaceItem.value : null;
    const coinsToPay = coinDifference !== null && coinDifference < 0 ? Math.abs(coinDifference) : 0;
    const hasEnoughCoins = balance >= coinsToPay;

    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 animate-fadeIn" onClick={onClose}>
            <div className="bg-white dark:bg-[#001233] rounded-lg shadow-xl w-full max-w-2xl border border-gray-200 dark:border-gray-700 p-6" onClick={e => e.stopPropagation()}>
                <h2 className="text-2xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-4">Propose Swap</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                    {/* Marketplace Item */}
                    <div className="text-center">
                        <p className="font-semibold text-sm text-gray-500 dark:text-gray-400 mb-2">Their Item</p>
                        <div className="bg-gray-100 dark:bg-[#001845] rounded-lg p-4 border border-gray-200 dark:border-gray-700">
                            <img src={marketplaceItem.imageUrl} alt={marketplaceItem.name} className="w-full h-32 object-cover rounded-md mb-2" />
                            <h3 className="font-bold text-[#001233] dark:text-[#EFEFDE] truncate">{marketplaceItem.name}</h3>
                             <div className="flex items-center justify-center gap-1 text-[#EE9B00] dark:text-[#E9D8A6] font-bold">
                                <span>{marketplaceItem.value.toLocaleString()}</span>
                                <CoinIcon className="w-4 h-4" />
                            </div>
                        </div>
                    </div>
                    
                    {/* User's Item Selection */}
                    <div className="text-center">
                        <p className="font-semibold text-sm text-gray-500 dark:text-gray-400 mb-2">Your Item</p>
                        <select
                            value={selectedUserItemId}
                            onChange={(e) => setSelectedUserItemId(e.target.value)}
                            className="w-full bg-gray-100 dark:bg-[#001845] border border-gray-300 dark:border-gray-600 text-[#001233] dark:text-[#EFEFDE] rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#2A67C9]"
                        >
                            <option value="" disabled>Select an item to swap...</option>
                            {userItems.map(item => (
                                <option key={item.id} value={item.id}>
                                    {item.name} (Value: {item.value.toLocaleString()})
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                {/* Coin Adjustment */}
                {coinDifference !== null && (
                    <div className="mt-6 p-4 rounded-lg bg-[#2A67C9]/10 dark:bg-[#2A67C9]/20 text-center animate-fadeIn">
                        <h3 className="font-bold text-lg text-[#001233] dark:text-[#EFEFDE]">Coin Adjustment</h3>
                        {coinDifference > 0 ? (
                             <p className="text-green-600 dark:text-green-400 font-semibold">You will receive {coinDifference.toLocaleString()} coins.</p>
                        ) : coinDifference < 0 ? (
                            <div>
                                <p className="text-red-600 dark:text-red-400 font-semibold">You need to pay {coinsToPay.toLocaleString()} coins.</p>
                                {!hasEnoughCoins && (
                                    <div className="mt-2 p-2 bg-red-100 dark:bg-red-900/50 rounded-lg flex items-center justify-center gap-2 text-sm">
                                        <AlertTriangleIcon className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0" />
                                        <div>
                                            <p className="font-bold text-red-700 dark:text-red-300">
                                                Coin shortage: You need {(coinsToPay - balance).toLocaleString()} more.
                                            </p>
                                            <button onClick={onBuyCoins} className="text-sky-600 dark:text-sky-400 hover:underline font-semibold">
                                                Buy Coins
                                            </button>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <p className="text-[#001233] dark:text-[#EFEFDE] font-semibold">This is an even swap! No coins needed.</p>
                        )}
                    </div>
                )}
                
                {proposalError && <p className="text-red-500 text-sm text-center mt-4">{proposalError}</p>}
                
                <div className="mt-8 flex justify-end gap-4">
                    <button onClick={onClose} className="border border-gray-400 text-[#001233] dark:bg-[#001845] dark:text-[#EFEFDE] dark:border-gray-600 font-bold py-2 px-4 rounded-lg hover:bg-gray-100 dark:hover:bg-[#001845]/80 transition-colors">Cancel</button>
                    <button 
                        onClick={handleProposeSwap}
                        disabled={!selectedUserItem || (coinsToPay > 0 && !hasEnoughCoins) || isProposing} 
                        className="bg-[#2A67C9] text-white font-bold py-2 px-4 rounded-lg hover:bg-[#255ab5] transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                         {isProposing && <div className="w-4 h-4 border-2 border-dashed rounded-full animate-spin border-white"></div>}
                         {isProposing ? 'Proposing...' : 'Propose Swap'}
                    </button>
                </div>
            </div>
        </div>
    );
};

const RangeSlider: React.FC<{
  min: number;
  max: number;
  value: { min: number; max: number };
  onChange: (value: { min: number; max: number }) => void;
  step?: number;
}> = ({ min, max, value, onChange, step = 50 }) => {
    const progressRef = useRef<HTMLDivElement>(null);
    const minTooltipRef = useRef<HTMLDivElement>(null);
    const maxTooltipRef = useRef<HTMLDivElement>(null);

    const handleMinChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        const newMinVal = Math.min(Number(e.target.value), value.max - step);
        onChange({ ...value, min: newMinVal });
    }, [onChange, value, step]);

    const handleMaxChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        const newMaxVal = Math.max(Number(e.target.value), value.min + step);
        onChange({ ...value, max: newMaxVal });
    }, [onChange, value, step]);

    useEffect(() => {
        if (progressRef.current && minTooltipRef.current && maxTooltipRef.current) {
            const range = max - min;
            const leftPercent = ((value.min - min) / range) * 100;
            const rightPercent = ((value.max - min) / range) * 100;

            progressRef.current.style.left = `${leftPercent}%`;
            progressRef.current.style.width = `${rightPercent - leftPercent}%`;
            minTooltipRef.current.style.left = `calc(${leftPercent}% - ${leftPercent * 0.16}px)`; // Approximate thumb offset
            maxTooltipRef.current.style.left = `calc(${rightPercent}% - ${rightPercent * 0.16}px)`;
        }
    }, [value, min, max]);

    return (
        <div className="relative h-10 flex items-center">
             <div ref={minTooltipRef} className="absolute -top-6 bg-[#001233] text-white text-xs rounded py-1 px-2 pointer-events-none">
                {value.min.toLocaleString()}
            </div>
            <div ref={maxTooltipRef} className="absolute -top-6 bg-[#001233] text-white text-xs rounded py-1 px-2 pointer-events-none">
                {value.max.toLocaleString()}
            </div>
            <div className="absolute w-full h-1 bg-gray-200 dark:bg-gray-700 rounded-full top-1/2 -translate-y-1/2">
                <div ref={progressRef} className="absolute h-1 bg-[#2A67C9] rounded-full"></div>
            </div>
            <input
                type="range" min={min} max={max} step={step} value={value.min}
                onChange={handleMinChange}
                className="absolute w-full appearance-none bg-transparent h-1"
                style={{ zIndex: 3 }}
                aria-label="Minimum value"
            />
            <input
                type="range" min={min} max={max} step={step} value={value.max}
                onChange={handleMaxChange}
                className="absolute w-full appearance-none bg-transparent h-1"
                style={{ zIndex: 4 }}
                aria-label="Maximum value"
            />
        </div>
    );
};

const AddItemModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onAddItem: (item: Omit<Item, 'id' | 'listedDate' | 'owner' | 'distance'>) => void;
  }> = ({ isOpen, onClose, onAddItem }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [category, setCategory] = useState<Item['category']>('Other');
    const [condition, setCondition] = useState<Item['condition']>('Used - Good');
    const [value, setValue] = useState('');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [isDragging, setIsDragging] = useState(false);
  
    const [errors, setErrors] = useState({ name: '', value: '', image: '', description: '' });
  
    const handleFileChange = (file: File | null) => {
        if (file && file.type.startsWith('image/')) {
            setImageFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result as string);
            };
            reader.readAsDataURL(file);
            setErrors(prev => ({ ...prev, image: '' }));
        }
    };

    const resetForm = () => {
        setName('');
        setDescription('');
        setCategory('Other');
        setCondition('Used - Good');
        setValue('');
        setImageFile(null);
        setImagePreview(null);
        setErrors({ name: '', value: '', image: '', description: '' });
    };

    const handleClose = () => {
        resetForm();
        onClose();
    }
  
    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      let hasError = false;
      const newErrors = { name: '', value: '', image: '', description: '' };
  
      if (!name.trim()) {
        newErrors.name = 'Product name is required.';
        hasError = true;
      }
      if (!description.trim()) {
        newErrors.description = 'Description is required.';
        hasError = true;
      }
      if (!value.trim() || isNaN(Number(value)) || Number(value) <= 0) {
        newErrors.value = 'A valid coin value is required.';
        hasError = true;
      }
      if (!imageFile || !imagePreview) {
        newErrors.image = 'An image is required.';
        hasError = true;
      }
  
      setErrors(newErrors);
  
      if (!hasError && imagePreview) {
        onAddItem({
          name,
          description,
          category,
          condition,
          value: Number(value),
          imageUrl: imagePreview,
        });
        handleClose();
      }
    };
  
    if (!isOpen) return null;
  
    return (
      <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 animate-fadeIn" onClick={handleClose}>
        <div className="bg-white dark:bg-[#001233] rounded-lg shadow-xl w-full max-w-2xl border border-gray-200 dark:border-gray-700" onClick={e => e.stopPropagation()}>
          <form onSubmit={handleSubmit}>
            <div className="p-6">
                <h2 className="text-2xl font-bold text-[#001233] dark:text-[#EFEFDE] mb-4">Add New Item</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Image Upload */}
                    <div>
                        <label htmlFor="file-upload" className="cursor-pointer">
                            <div
                                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                                onDragLeave={(e) => { e.preventDefault(); setIsDragging(false); }}
                                onDrop={(e) => {
                                    e.preventDefault();
                                    setIsDragging(false);
                                    handleFileChange(e.dataTransfer.files?.[0] || null);
                                }}
                                className={`relative w-full h-48 border-2 border-dashed rounded-lg flex flex-col items-center justify-center transition-colors duration-300 ${isDragging ? 'border-[#2A67C9] bg-[#2A67C9]/10' : (errors.image ? 'border-red-500' : 'border-gray-300 dark:border-gray-600 hover:border-[#2A67C9]')}`}
                            >
                                <input id="file-upload" type="file" className="sr-only" onChange={e => handleFileChange(e.target.files?.[0] || null)} accept="image/*" />
                                {imagePreview ? (
                                    <img src={imagePreview} alt="Item Preview" className="absolute inset-0 w-full h-full object-cover rounded-lg" />
                                ) : (
                                    <div className="text-center text-[#001233] dark:text-[#EFEFDE]">
                                        <UploadIcon className="mx-auto h-10 w-10" />
                                        <p className="mt-2 font-semibold">Upload a photo</p>
                                    </div>
                                )}
                            </div>
                        </label>
                        {errors.image && <p className="text-red-500 text-xs mt-1">{errors.image}</p>}
                    </div>
                    {/* Form Fields */}
                    <div className="space-y-4">
                        <div>
                            <label className="text-sm font-semibold">Name</label>
                            <input type="text" value={name} onChange={e => setName(e.target.value)} className={`w-full mt-1 p-2 border rounded ${errors.name ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} bg-gray-50 dark:bg-[#001845]`} />
                            {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                        </div>
                         <div>
                            <label className="text-sm font-semibold">Value (Coins)</label>
                            <input type="number" value={value} onChange={e => setValue(e.target.value)} className={`w-full mt-1 p-2 border rounded ${errors.value ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} bg-gray-50 dark:bg-[#001845]`} />
                            {errors.value && <p className="text-red-500 text-xs mt-1">{errors.value}</p>}
                        </div>
                    </div>
                     <div className="md:col-span-2">
                        <label className="text-sm font-semibold">Description</label>
                        <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} className={`w-full mt-1 p-2 border rounded ${errors.description ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} bg-gray-50 dark:bg-[#001845] resize-none`}></textarea>
                        {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
                    </div>
                     <div className="grid grid-cols-2 gap-4 md:col-span-2">
                         <div>
                            <label className="text-sm font-semibold">Category</label>
                            <select value={category} onChange={e => setCategory(e.target.value as Item['category'])} className="w-full mt-1 p-2 border rounded border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-[#001845]">
                                {['Electronics', 'Apparel', 'Furniture', 'Collectibles', 'Other'].map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                         <div>
                            <label className="text-sm font-semibold">Condition</label>
                             <select value={condition} onChange={e => setCondition(e.target.value as Item['condition'])} className="w-full mt-1 p-2 border rounded border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-[#001845]">
                                {['New', 'Used - Like New', 'Used - Good', 'Used - Fair'].map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div className="bg-gray-50 dark:bg-[#001845] px-6 py-4 flex justify-end gap-4 rounded-b-lg">
                <button type="button" onClick={handleClose} className="border border-gray-400 font-bold py-2 px-4 rounded-lg hover:bg-gray-100 transition-colors">Cancel</button>
                <button type="submit" className="bg-[#2A67C9] text-white font-bold py-2 px-4 rounded-lg hover:bg-[#255ab5] transition-colors">Add Item</button>
            </div>
          </form>
        </div>
      </div>
    );
};
  
const MyItemCard: React.FC<{ item: Item }> = ({ item }) => (
    <div className="bg-white dark:bg-[#001233] rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 group transform transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg flex flex-col">
        <img src={item.imageUrl} alt={item.name} className="w-full h-40 object-cover" />
        <div className="p-3 flex flex-col flex-grow">
            <h3 className="font-bold text-sm text-[#001233] dark:text-[#EFEFDE] truncate">{item.name}</h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">{item.condition}</p>
            <div className="flex justify-between items-center mt-auto pt-2 border-t border-gray-100 dark:border-gray-700">
                <div className="flex items-center gap-1 font-bold text-[#EE9B00] dark:text-[#E9D8A6]">
                    <CoinIcon className="w-5 h-5" />
                    <span>{item.value.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-1">
                    <button className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-[#001845] transition-colors" aria-label="Edit item">
                        <PencilIcon className="w-4 h-4 text-gray-600 dark:text-gray-300" />
                    </button>
                    <button className="p-2 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50 transition-colors" aria-label="Delete item">
                        <TrashIcon className="w-4 h-4 text-red-600 dark:text-red-400" />
                    </button>
                </div>
            </div>
        </div>
    </div>
);

const FilterSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div>
      <h4 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3">{title}</h4>
      {children}
    </div>
);

const FilterButton: React.FC<{ onClick: () => void; isActive: boolean; children: React.ReactNode }> = ({ onClick, isActive, children }) => (
    <button
        onClick={onClick}
        className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-colors duration-200 ${isActive ? 'bg-[#2A67C9] text-white border-[#2A67C9]' : 'bg-transparent text-[#001233] dark:text-[#EFEFDE] border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-[#001845]'}`}
    >
        {children}
    </button>
);

type ActiveTab = 'my-items' | 'explore';
type SortByType = 'newest' | 'value_desc' | 'value_asc';
const categories = ['Electronics', 'Apparel', 'Furniture', 'Collectibles', 'Other'];
const conditions = ['New', 'Used - Like New', 'Used - Good', 'Used - Fair'];
const radiusOptions = [3, 5, 8, 10, 25, Infinity];
const radiusLabels = ['< 3 km', '< 5 km', '< 8 km', '< 10 km', '< 25 km', 'Any'];
const MAX_VALUE = 3000;

const ItemsPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<ActiveTab>('explore');
  
  const [marketplaceItems, setMarketplaceItems] = useState<Item[]>([]);
  const [userItems, setUserItems] = useState<Item[]>([]);
  const [transactions, setTransactions] = useState<CoinTransaction[]>([]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [valueRange, setValueRange] = useState({ min: 0, max: MAX_VALUE });
  const [selectedCondition, setSelectedCondition] = useState<string>('all');
  const [selectedRadius, setSelectedRadius] = useState<number>(Infinity);
  const [sortBy, setSortBy] = useState<SortByType>('newest');
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [isSwapModalOpen, setIsSwapModalOpen] = useState(false);
  const [isAddCoinsModalOpen, setIsAddCoinsModalOpen] = useState(false);
  const [isAddItemModalOpen, setIsAddItemModalOpen] = useState(false);
  const [selectedMarketplaceItem, setSelectedMarketplaceItem] = useState<Item | null>(null);
  const [isFiltersVisible, setIsFiltersVisible] = useState(false);

  const [previewState, setPreviewState] = useState<{ item: Item; position: { top: number; left: number } } | null>(null);
  const showTimerRef = useRef<number | null>(null);
  const hideTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
        if (showTimerRef.current) clearTimeout(showTimerRef.current);
        if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, []);

  const handleCardMouseEnter = (item: Item, e: React.MouseEvent<HTMLDivElement>) => {
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
      if (showTimerRef.current) clearTimeout(showTimerRef.current);

      showTimerRef.current = window.setTimeout(() => {
          const rect = e.currentTarget.getBoundingClientRect();
          setPreviewState({ item, position: { top: rect.top, left: rect.right + 16 } });
      }, 2000);
  };

  const handleCardMouseLeave = () => {
      if (showTimerRef.current) clearTimeout(showTimerRef.current);
      hideTimerRef.current = window.setTimeout(() => setPreviewState(null), 300);
  };

  const handlePreviewMouseEnter = () => {
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
  };

  const handlePreviewMouseLeave = () => {
      hideTimerRef.current = window.setTimeout(() => setPreviewState(null), 300);
  };

  useEffect(() => {
    const fetchItemsAndBalance = async () => {
        if (!currentUser) return;
      const [market, user, trans] = await Promise.all([
        getMarketplaceItems(), 
        getMockItemsForUser(currentUser.username),
        getMockCoinTransactions(currentUser.username)
      ]);
      setMarketplaceItems(market);
      setUserItems(user.sort((a,b) => new Date(b.listedDate).getTime() - new Date(a.listedDate).getTime()));
      setTransactions(trans);
    };
    fetchItemsAndBalance();
  }, [currentUser]);

  const handleAddItem = (newItemData: Omit<Item, 'id' | 'listedDate' | 'owner' | 'distance'>) => {
    if (!currentUser) return;
    const newItem: Item = {
        id: `u-${Date.now()}`,
        ...newItemData,
        listedDate: new Date().toISOString(),
        owner: {
            username: currentUser.username,
            avatarUrl: currentUser.avatarUrl,
        },
        distance: 0
    };
    setUserItems(prevItems => [newItem, ...prevItems]);
  };
  
  const radiusIndex = useMemo(() => selectedRadius === Infinity ? 5 : radiusOptions.findIndex(r => r === selectedRadius), [selectedRadius]);

  const balance = useMemo(() => {
    return transactions.reduce((acc, tx) => acc + (tx.type === 'Credit' ? tx.amount : -Math.abs(tx.amount)), 0);
  }, [transactions]);
  
  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedCondition('all');
    setValueRange({ min: 0, max: MAX_VALUE });
    setSelectedRadius(Infinity);
  };

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (searchQuery.trim() !== '') count++;
    if (selectedCategory !== 'all') count++;
    if (selectedCondition !== 'all') count++;
    if (valueRange.min !== 0 || valueRange.max !== MAX_VALUE) count++;
    if (selectedRadius !== Infinity) count++;
    return count;
  }, [searchQuery, selectedCategory, selectedCondition, valueRange, selectedRadius]);

  const handleAddCoins = (amount: number) => {
    navigate('/payment-gateway', { state: { amount } });
    setIsAddCoinsModalOpen(false);
  };

  const toggleFavorite = (itemId: string) => {
    setFavorites(prev => {
      const newFavs = new Set(prev);
      if (newFavs.has(itemId)) {
        newFavs.delete(itemId);
      } else {
        newFavs.add(itemId);
      }
      return newFavs;
    });
  };

  const handleSwapNow = (item: Item) => {
    setSelectedMarketplaceItem(item);
    setIsSwapModalOpen(true);
  };

  const handleBuyCoinsClick = () => {
    setIsSwapModalOpen(false);
    setIsAddCoinsModalOpen(true);
  };

  const handleStartChat = (item: Item) => {
    const mockConvoMap: { [key: string]: string } = { 'm1': 'convo1', 'm3': 'convo2', 'm7': 'convo3' };
    const convoId = mockConvoMap[item.id] || 'convo1';
    navigate(`/messages/${convoId}`);
  };

  const displayedMarketplaceItems = useMemo(() => {
    return marketplaceItems
      .filter(item => {
        const searchMatch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
        const categoryMatch = selectedCategory === 'all' || item.category === selectedCategory;
        const conditionMatch = selectedCondition === 'all' || item.condition === selectedCondition;
        const valueMatch = item.value >= valueRange.min && item.value <= valueRange.max;
        const radiusMatch = selectedRadius === Infinity || item.distance <= selectedRadius;
        return searchMatch && categoryMatch && conditionMatch && valueMatch && radiusMatch;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'value_desc': return b.value - a.value;
          case 'value_asc': return a.value - b.value;
          case 'newest':
          default:
            return new Date(b.listedDate).getTime() - new Date(a.listedDate).getTime();
        }
      });
  }, [marketplaceItems, searchQuery, selectedCategory, selectedCondition, valueRange, sortBy, selectedRadius]);

  const inputClass = "bg-white dark:bg-[#001845] border border-gray-300 dark:border-gray-600 text-[#001233] dark:text-[#EFEFDE] rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#2A67C9] transition-colors";
  
  const TabButton: React.FC<{ tabName: ActiveTab; label: string }> = ({ tabName, label }) => (
    <button
        onClick={() => setActiveTab(tabName)}
        className={`px-4 py-2 text-lg font-semibold transition-colors duration-300 relative ${activeTab === tabName ? 'text-[#2A67C9] dark:text-[#E9D8A6]' : 'text-gray-500 hover:text-[#001233] dark:hover:text-white'}`}
    >
        {label}
        {activeTab === tabName && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-[#2A67C9] dark:bg-[#E9D8A6] rounded-full"></span>}
    </button>
  );

  return (
    <div className="animate-fadeIn">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-[#001233] dark:text-[#EFEFDE]">Items</h1>
        <div className="mt-4 border-b border-gray-200 dark:border-gray-700">
            <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                <TabButton tabName="my-items" label="My Items" />
                <TabButton tabName="explore" label="Explore Items" />
            </nav>
        </div>
      </div>
      
      <div key={activeTab} className="animate-fadeIn">
        {activeTab === 'my-items' && (
            <div>
                <div className="flex justify-between items-center mb-6">
                    <p className="text-gray-600 dark:text-gray-400">Manage the items you have listed for swapping.</p>
                    <button onClick={() => setIsAddItemModalOpen(true)} className="bg-[#2A67C9] text-white font-bold py-2 px-4 rounded-lg hover:bg-[#255ab5] transition-colors flex items-center justify-center gap-2">
                        <PlusIcon className="w-5 h-5" />
                        Add New Item
                    </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-4">
                    {userItems.map(item => <MyItemCard key={item.id} item={item} />)}
                </div>
                {userItems.length === 0 && (
                     <div className="text-center text-gray-500 dark:text-gray-400 py-20">
                        <p className="text-lg font-semibold mt-4">You haven't listed any items yet.</p>
                        <p>Click "Add New Item" to get started!</p>
                    </div>
                )}
            </div>
        )}

        {activeTab === 'explore' && (
            <div>
                <div className="mb-6 p-4 bg-white dark:bg-[#001233] rounded-lg border border-gray-200 dark:border-gray-700">
                    <div className="flex flex-col md:flex-row items-center gap-4">
                        <div className="relative w-full flex-grow">
                            <input
                            type="text"
                            placeholder="Search by name..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className={`${inputClass} w-full pl-10`}
                            />
                            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                        </div>
                        <button onClick={() => setIsFiltersVisible(!isFiltersVisible)} className="flex-shrink-0 w-full md:w-auto relative flex items-center justify-center gap-2 border border-gray-300 dark:border-gray-600 text-[#001233] dark:text-[#EFEFDE] rounded-lg py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                            <AdjustmentsHorizontalIcon className="w-5 h-5"/>
                            <span>Filters</span>
                            {activeFilterCount > 0 && (
                                <span className="absolute -top-2 -right-2 w-5 h-5 bg-[#2A67C9] text-white text-xs font-bold rounded-full flex items-center justify-center">
                                    {activeFilterCount}
                                </span>
                            )}
                        </button>
                    </div>

                    <div className={`transition-all duration-300 ease-in-out overflow-hidden ${isFiltersVisible ? 'max-h-[30rem] mt-4 pt-4 border-t border-gray-200 dark:border-gray-700' : 'max-h-0'}`}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                            <FilterSection title="Category">
                                <div className="flex flex-wrap gap-2">
                                    <FilterButton onClick={() => setSelectedCategory('all')} isActive={selectedCategory === 'all'}>All</FilterButton>
                                    {categories.map(c => (
                                        <FilterButton key={c} onClick={() => setSelectedCategory(c)} isActive={selectedCategory === c}>{c}</FilterButton>
                                    ))}
                                </div>
                            </FilterSection>

                            <FilterSection title="Condition">
                                <div className="flex flex-wrap gap-2">
                                    <FilterButton onClick={() => setSelectedCondition('all')} isActive={selectedCondition === 'all'}>All</FilterButton>
                                    {conditions.map(c => (
                                        <FilterButton key={c} onClick={() => setSelectedCondition(c)} isActive={selectedCondition === c}>{c}</FilterButton>
                                    ))}
                                </div>
                            </FilterSection>

                            <div className="md:col-span-2">
                                <FilterSection title="Value Range">
                                    <RangeSlider min={0} max={MAX_VALUE} value={valueRange} onChange={setValueRange} />
                                </FilterSection>
                            </div>
                            
                            <div className="md:col-span-2">
                                <FilterSection title="Distance">
                                    <div className="px-2">
                                        <input
                                            type="range"
                                            min="0"
                                            max="5"
                                            value={radiusIndex}
                                            onChange={(e) => setSelectedRadius(radiusOptions[Number(e.target.value)])}
                                            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                                            style={{ accentColor: '#2A67C9' }}
                                        />
                                        <div className="text-center text-sm font-semibold text-[#001233] dark:text-white mt-2">
                                            {radiusLabels[radiusIndex]}
                                        </div>
                                    </div>
                                </FilterSection>
                            </div>
                        </div>
                        <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-end">
                            <button onClick={handleResetFilters} className="text-sm font-semibold text-[#2A67C9] dark:text-[#E9D8A6] hover:underline">
                                Reset All Filters
                            </button>
                        </div>
                    </div>
                </div>
                 <div className="flex justify-between items-center mb-6 px-1">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                    Showing <span className="font-bold text-[#001233] dark:text-white">{displayedMarketplaceItems.length}</span> results
                    </p>
                    <div className="flex items-center gap-2">
                        <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">Sort By:</label>
                        <select value={sortBy} onChange={e => setSortBy(e.target.value as SortByType)} className={`${inputClass} text-sm`}>
                            <option value="newest">Newest</option>
                            <option value="value_desc">Highest Value</option>
                            <option value="value_asc">Lowest Value</option>
                        </select>
                    </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-4">
                    {displayedMarketplaceItems.map((item) => (
                    <div 
                        key={item.id} 
                        className={`bg-white dark:bg-[#001233] rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 group transform transition-transform duration-300 shadow-sm dark:shadow-none flex flex-col ${previewState?.item.id === item.id ? 'scale-110 z-40 shadow-xl dark:shadow-black/50' : 'hover:-translate-y-1 hover:scale-105'}`}
                        onMouseEnter={(e) => handleCardMouseEnter(item, e)}
                        onMouseLeave={handleCardMouseLeave}
                    >
                        <div className="relative">
                        <img src={item.imageUrl} alt={item.name} className="w-full h-32 object-cover" />
                        <button onClick={() => toggleFavorite(item.id)} className="absolute top-2 right-2 bg-white/80 dark:bg-black/50 rounded-full p-1.5 hover:scale-110 transition-transform duration-200" aria-label={favorites.has(item.id) ? "Remove from favorites" : "Add to favorites"}>
                            <HeartIcon className={`w-5 h-5 transition-colors ${favorites.has(item.id) ? 'text-red-500' : 'text-gray-600 dark:text-gray-300'}`} filled={favorites.has(item.id)} />
                        </button>
                        </div>
                        <div className="p-2 flex flex-col flex-grow">
                        <h3 className="text-sm font-bold text-[#001233] dark:text-[#EFEFDE] mb-1 truncate">{item.name}</h3>
                        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mb-2">
                            <div className="flex items-center gap-1.5">
                                <img src={item.owner.avatarUrl} alt={item.owner.username} className="w-4 h-4 rounded-full object-cover" />
                                <span className="truncate">@{item.owner.username}</span>
                            </div>
                            <div className="flex items-center gap-1">
                                <MapPinIcon className="w-3 h-3" />
                                <span>{item.distance.toFixed(1)} km</span>
                            </div>
                        </div>
                        <div className="flex justify-between items-center mt-auto">
                            <div className="flex items-center gap-1 text-base font-bold text-[#EE9B00] dark:text-[#E9D8A6]">
                            <CoinIcon className="w-5 h-5" />
                            <span>{item.value.toLocaleString()}</span>
                            </div>
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                                <button onClick={() => handleStartChat(item)} className="bg-[#E9D8A6] text-black/70 text-xs font-bold py-1.5 px-2.5 rounded-md hover:bg-[#d9c496] transition-colors">
                                    Message
                                </button>
                                <button onClick={() => handleSwapNow(item)} className="bg-[#2A67C9] text-white text-xs font-bold py-1.5 px-2.5 rounded-md hover:bg-[#255ab5] transition-colors">
                                    Swap
                                </button>
                            </div>
                        </div>
                        </div>
                    </div>
                    ))}
                </div>
                 {displayedMarketplaceItems.length === 0 && (
                    <div className="col-span-full text-center text-gray-500 dark:text-gray-400 py-20">
                        <SwapsIcon className="w-16 h-16 mx-auto text-gray-300 dark:text-gray-600" />
                        <p className="text-lg font-semibold mt-4">No items found</p>
                        <p>Try adjusting your filters to find the perfect swap.</p>
                    </div>
                )}
            </div>
        )}
      </div>

      <SwapModal 
        isOpen={isSwapModalOpen}
        onClose={() => setIsSwapModalOpen(false)}
        marketplaceItem={selectedMarketplaceItem}
        userItems={userItems}
        balance={balance}
        onBuyCoins={handleBuyCoinsClick}
        currentUser={currentUser}
      />
      <AddCoinsModal
        isOpen={isAddCoinsModalOpen}
        onClose={() => setIsAddCoinsModalOpen(false)}
        onAddCoins={handleAddCoins}
      />
      <AddItemModal 
        isOpen={isAddItemModalOpen}
        onClose={() => setIsAddItemModalOpen(false)}
        onAddItem={handleAddItem}
      />

      {previewState && (
          <ItemPreviewCard 
              item={previewState.item} 
              position={previewState.position} 
              onMouseEnter={handlePreviewMouseEnter}
              onMouseLeave={handlePreviewMouseLeave}
          />
      )}
    </div>
  );
};

export default ItemsPage;